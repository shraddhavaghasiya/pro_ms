<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\IntegrationController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/sessionStatus', [AuthController::class, 'sessionStatus']);

Route::get('/sendOnesignalNotification', [IntegrationController::class, 'sendOnesignalNotification']);
Route::get('/testt', [\App\Http\Controllers\TestController::class, 'test']);

Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout']);

Route::group(['prefix' => 'dashboard', 'as' => 'dashboard.'], function () {
    Route::get('/count', [DashboardController::class, 'count'])->name('count');
});
Route::group(['axios' => 'userProfile', 'prefix' => 'profile'], function () {
    Route::get('/get-admin-profile', [AuthController::class,'getAdminProfile'])->name('get-admin-profile');
    Route::post('/user-profile-update', [AuthController::class,'adminProfileUpdate'])->name('update');
});



Route::group(['prefix' => 'product', 'as' => 'product.'], function () {
    Route::get('/get-category', [ProductController::class,'getCategory'])->name('category');

    Route::get('/count', [ProductController::class, 'productCount'])->name('count');
    Route::get('/admin-product-list/{count}', [ProductController::class, 'productList'])->name('list');
    Route::get('/admin-product-search/{count}/{search}', [ProductController::class, 'productSearch'])->name('search');

    Route::post('/admin-product-register', [ProductController::class,'productRegister'])->name('register');
    Route::post('/admin-product-update', [ProductController::class,'productUpdate'])->name('update');
    Route::post('/product-delete-update', [ProductController::class,'productDeleteUpdate'])->name('delete');
    Route::post('/product-status-update', [ProductController::class,'productStatusUpdate'])->name('status');

    Route::get('/admin-product-show/{product}', [ProductController::class,'productShow'])->name('edit-show'); //vue edit page in show product data like Ajax
    Route::post('/product-image-delete', [ProductController::class,'productImageDelete'])->name('delete'); // specific image delete

});

Route::group(['prefix' => 'user', 'as' => 'user.'], function () {
    Route::get('/admin-user-list/{count}', [AdminController::class, 'userList'])->name('list');
    Route::get('/admin-user-search/{count}/{search}', [AdminController::class, 'userSearch'])->name('search');
    Route::post('/user-delete-update', [AdminController::class,'userDeleteUpdate'])->name('delete');
    Route::post('/user-status-update', [AdminController::class,'userStatusUpdate'])->name('status');
    Route::post('/user-price-view-status-update', [AdminController::class,'userPriceViewStatusUpdate'])->name('price-view-status');
});

Route::get('/{any}', [PageController::class, 'index'])->where('any', '.*');
