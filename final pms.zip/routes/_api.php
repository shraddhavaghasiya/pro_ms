<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::get('get_products',[ProductController::class, 'index']);
//Route::post('login',[ProductController::class, 'login']);
//Route::post('register',[ProductController::class, 'register']);
//Route::post('products',[ProductController::class, 'products']);
//Route::post('products',[ProductController::class, 'index']);

Route::group(['middleware'=>'api'],function ($routes){
    Route::post('/register',[ProductController::class, 'register']);
    Route::post('/login',[ProductController::class, 'login']);
    Route::post('/products',[ProductController::class, 'products']);
//    Route::get('/products',[ProductController::class, 'products']);
});

//Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//    return $request->user();
//});
