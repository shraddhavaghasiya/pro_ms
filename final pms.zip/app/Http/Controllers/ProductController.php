<?php

namespace App\Http\Controllers;

use App\Events\SendOneSignalNotification;
use App\Models\Category;
use App\Models\ChinaPriceUser;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function getCategory()
    {
        $category = Category::where('status', '=', 1)->get();
        if ($category) {
            return response()->json(['success' => true, 'category' => $category], 200);
        } else {
            return response()->json(['success' => false, 'message' => 'Category not found'], 200);
        }
    }

    public function productList($perPage)
    {
//        $productLists = Product::where([['status', '!=', 0], ['deleted_status', '!=', 1]])->with('product_images')->paginate($perPage);
        $productLists = Product::where([['deleted_status', '!=', 1]])->with(['product_images','category'])->paginate($perPage);

        if (count($productLists) > 0) {
            return response()->json(['success' => true, 'productLists' => $productLists], 200);
        } else {
            return response()->json(['success' => false, 'message' => 'Product Not Found'], 200);
        }
    }

    public function productSearch($perpage, $query)
    {
        $search_product = Product::where([['deleted_status', '!=', 1],['name', 'like', '%' . $query . '%']])
            ->orWhere([['deleted_status', '!=', 1],['qty', 'like', '%' . $query . '%']])
            ->orWhere([['deleted_status', '!=', 1],['price', 'like', '%' . $query . '%']])
            ->orWhere([['deleted_status', '!=', 1],['china_price', 'like', '%' . $query . '%']])
            ->with(['product_images','category'])->paginate($perpage);
//        $search_product = Product::where([['deleted_status', '!=', 1],['name', 'like', '%' . $query . '%']])
//            ->orWhere([['deleted_status', '!=', 1],['qty', 'like', '%' . $query . '%']])
//            ->orWhere([['deleted_status', '!=', 1],['price', 'like', '%' . $query . '%']])
//            ->paginate($perpage);

        if ($search_product) {
            return response()->json($search_product, 200);
        } else {
            return response()->json(['success' => false, 'message' => 'Search Product Not Available'], 200);
        }
    }

    public function productRegister(Request $request)
    {
//        echo "<PRE>";print_r($request->all());die();

        $request->validate([
            'name' => ['required'],
            'price' => ['required'],
            'china_price' => ['required'],
            'qty' => ['required'],
            'tag' => ['required'],
            'category' => ['required'],
            'description' => ['required'],
            'product_image' => ['required'],
        ]);


        $product = new Product();
        $product->user_id = Auth::user()->id;
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->china_price = $request->china_price;
        $product->qty = $request->qty;
        $product->tag = $request->tag;
        $product->category_id = $request->category;
        $product->status = 1;

        if ($request->hasFile('product_image')) {
            if ($request->hasFile('product_image')) {
                $this->validate($request, ['product_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048']);

                $images_cover = $request->file('product_image');
                $fileNamewithExt = $images_cover->getClientOriginalName();  // 1. image filename with extension
                $fileName = pathinfo($fileNamewithExt, PATHINFO_FILENAME);  //2. get profile_image name
                $fileExtension = $images_cover->getClientOriginalExtension();   //3. get profile_image extension
                $fileNameToStore = 'p_' . md5('pt_' . date('Y_m_d_Hi', time())) . '.' . $fileExtension;    //4. combinefile name and extension
                $path = $images_cover->storeAs('/public/product_thumbnail', $fileNameToStore); // upload profile_image name
            } else {
                $fileNameToStore = 'product_thumbnail.jpg';
            }
            $product->image = 'product_thumbnail/' . $fileNameToStore;
        } else {
            $product->image = 'product_thumbnail/product_thumbnail.jpg';
        }

        $product->save();

        if ($product) {
            $c_product_id = $product->id;

            if ($request->hasFile('product_multi_image')) {
                $images_covers = $request->file('product_multi_image');
                $image_count = count($images_covers);

                for ($i = 0; $i < $image_count; $i++) {
                    if ($request->file('product_multi_image')[$i]) {
                        $images_cover = $request->file('product_multi_image')[$i];
                        $fileNamewithExt = $images_cover->getClientOriginalName();  // 1. image filename with extension
                        $fileName = pathinfo($fileNamewithExt, PATHINFO_FILENAME);  //2. get product_multi_image name
                        $fileExtension = $images_cover->getClientOriginalExtension();   //3. get product_multi_image extension
                        $fileNameToStore = 'p' . $c_product_id . '_' . md5('pi_' . date('Y_m_d_Hi', time())) . '_' . md5(microtime(true)) . '.' . $fileExtension;    //4. combinefile name and extension
                        $path = $images_cover->storeAs('/public/product_images', $fileNameToStore); // upload product_multi_image name
                    } else {
                        $fileNameToStore = 'p_image.jpg';
                    }
                    $product_image = new ProductImage();
                    $product_image->product_id = $c_product_id;
                    $product_image->image = 'product_images/' . $fileNameToStore;
                    $product_image->status = 1;
                    $product_image->save();
                }
            }
        }

        $productInfo = Product::where('id', '=', $product->id)->with('product_images')->first();
//        SendOneSignalNotification::dispatch('added', $productInfo->name);
        SendOneSignalNotification::dispatch('Introducing Our Latest Addition:', $productInfo->name);

        if ($productInfo) {
            return response()->json(['success' => true, 'message' => 'Product Added Successfully', 'productInfo' => $productInfo], 200);
        } else {
            return response()->json(['success' => false, 'message' => 'Product Not Added Successfully']);
        }
    }

    public function productUpdate(Request $request)
    {
        $product_update = Product::where('id', '=', $request->pid)->first();
//        return $product_update;
        $product_update->user_id = auth()->user()->id;

        $product_update->name = $request->name;
        $product_update->description = $request->description;

        $product_update->price = $request->price;
        $product_update->china_price = $request->china_price;
        $product_update->qty = $request->qty;
        $product_update->tag = $request->tag;
        $product_update->category_id = $request->category;

        if ($request->hasFile('product_image')) {

            if ($request->hasFile('product_image')) {
//                dd($request->file('product_image'));
                $this->validate($request, ['product_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048']);

                $images_cover = $request->file('product_image');
                $fileNamewithExt = $images_cover->getClientOriginalName();  // 1. image filename with extension
                $fileName = pathinfo($fileNamewithExt, PATHINFO_FILENAME);  //2. get product_image name
                $fileExtension = $images_cover->getClientOriginalExtension();   //3. get product_image extension
                $fileNameToStore = 'p' . $product_update->id . '_' . md5('pt_' . date('Y_m_d_Hi', time())) . '.' . $fileExtension;    //4. combinefile name and extension
                $path = $images_cover->storeAs('/public/product_thumbnail', $fileNameToStore); // upload product_image name
            } else {
                $fileNameToStore = 'product_thumbnail.jpg';
            }
            $product_update->image = 'product_thumbnail/' . $fileNameToStore;
        }
        $product_update->save();

        if ($product_update) {
            $c_product_id = $product_update->id;

            if ($request->hasFile('product_multi_image')) {
                $images_covers = $request->file('product_multi_image');
                $image_count = count($images_covers);

                for ($i = 0; $i < $image_count; $i++) {
                    //$this->validate($request, ['product_multi_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048']);
                    $fileNameToStore = '';
                    if ($request->file('product_multi_image')[$i]) {
                        $images_cover = $request->file('product_multi_image')[$i];
                        $fileNamewithExt = $images_cover->getClientOriginalName();  // 1. image filename with extension
                        $fileName = pathinfo($fileNamewithExt, PATHINFO_FILENAME);  //2. get product_multi_image name
                        $fileExtension = $images_cover->getClientOriginalExtension();   //3. get product_multi_image extension
                        $fileNameToStore = 'p' . $c_product_id . '_' . md5('pi_' . date('Y_m_d_Hi', time())) . '_' . md5(microtime(true)) . '.' . $fileExtension;    //4. combinefile name and extension
                        $path = $images_cover->storeAs('/public/product_images', $fileNameToStore); // upload product_multi_image name
                    } else {
                        $fileNameToStore = 'p_image.jpg';
                    }
                    $product_update = new ProductImage();
                    $product_update->product_id = $c_product_id;
                    $product_update->image = 'product_images/' . $fileNameToStore;
                    $product_update->status = 1;
                    $product_update->save();
                }
            }
        }
        SendOneSignalNotification::dispatch('updated', $product_update->name);
        return response()->json(['success' => true, 'message' => 'Product upload successfully'], 200);
    }

    public function productDeleteUpdate(Request $request)
    {
        $delete = Product::where('id', $request->id)->first();
        $delete_name = $delete->name;
        if ($delete) {
            $delete->deleted_status = 1;
            $delete->save();
            SendOneSignalNotification::dispatch('deleted', $delete_name);
            return response()->json(['success' => 'Product Delete done Successfully'], 200);
        } else {
            return response()->json(['error' => 'Product delete time error occurs'], 200);
        }
    }

    public function productShow($product_id)
    {
        $product = Product::where('id', '=', $product_id)->with('product_images:id,product_id,image,status')->first();
        if ($product) {
            return response()->json(['success' => true, 'product' => $product], 200);
        } else {
            return response()->json(['success' => false, 'message' => 'Product not found'], 200);
        }
    }

    public function productImageDelete(Request $request)
    {

        $product_image = ProductImage::where('id', '=', $request->id)->first();
        if ($product_image->image !== 'product_images/p_image.jpg') {
            if (Storage::exists('public/' . $product_image->image)) {
                Storage::delete('public/' . $product_image->image);
            }
        }
        $product_image->delete();
        return response()->json(['success' => true, 'message' => 'Image deleted successfully'], 200);
        //$str = "../storage/product_images/P-06e55bc89e40ec880cd1fbb06b95d3f1.jpg";    //print_r (explode("storage/",$str));
    }

    public function productStatusUpdate(Request $request)
    {
        $productUpdate = Product::where('id', $request->productId)->first();
        if ($productUpdate) {
            $productUpdate->status = $request->status;
            $productUpdate->save();

            return response()->json(['success' => 'Product Status Update Successfully', 'status' => $request->status], 200);
        } else {
            return response()->json(['error' => 'Product Status Update Error'], 200);
        }
    }
}
