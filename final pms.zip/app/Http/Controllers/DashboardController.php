<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\User;

class DashboardController extends Controller
{
    //
    public function count()
    {
//        $productsCounts = Product::where([['status', '!=', 0], ['deleted_status', '!=', 1]])->count();
        $productsCounts = Product::where([['deleted_status', '!=', 1]])->count();
        $usersCounts = User::count();
//        echo "<PRE>";print_r($productsCount);die;
        return response()->json(['success' => true, 'productsCounts' => $productsCounts, 'usersCounts' => $usersCounts]);
    }


}
