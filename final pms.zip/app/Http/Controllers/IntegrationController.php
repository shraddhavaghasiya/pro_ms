<?php

namespace App\Http\Controllers;

use App\Models\User;

class IntegrationController extends Controller
{
    //
    public static function sendOnesignalNotification($action, $message)
    {
        $fcm_ids = User::where('status', 1)->whereNotNull('fcm_id')->pluck('fcm_id');

        $appId = '5fb84bc5-d10d-42e2-b470-e262041b50b9';
        $restApiKey = 'ZDIwODI5MzAtZDE2Yy00YTRlLTk4ZmMtODkwNjc1YWIxZTI3';

        $content = [
            'en' => $message
        ];
        $title = 'Product ' . $action;
//        $icon = 'https://skilltocode.com/storage/avatar/avatar32262b1cb858c460c3080dcc8539bd5e.png'; // Replace with your icon URL
        $icon = 'https://skilltocode.com/storage/product_thumbnail/product_thumbnail.jpg'; // Replace with your icon URL

        $fields = [
            'app_id' => $appId,
            'include_player_ids' => $fcm_ids,
            'headings' => ['en' => $title], // Notification title
            'contents' => $content, // Notification content
            'small_icon' => $icon // Notification icon
        ];

        $fields = json_encode($fields);

        // Set the request headers
        $headers = [
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic ' . $restApiKey,
        ];

        // Initialize cURL session
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $result = curl_exec($ch);

        if (curl_errno($ch)) {
            echo 'Error: ' . curl_error($ch);
        }

        // Close cURL session
        curl_close($ch);

        return;
        // Output the result (you might handle this differently in production)
        //echo $result; // {"id":"5e069cb7-1dae-4781-b474-296574431c4d","external_id":null}
    }
}
