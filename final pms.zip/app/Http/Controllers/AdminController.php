<?php

namespace App\Http\Controllers;


use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    //
    public function userList($perPage)
    {
        $userLists = User::where([['deleted_status', '!=', 1]])->paginate($perPage);

        if (count($userLists) > 0) {
            return response()->json(['success' => true, 'userLists' => $userLists], 200);
        } else {
            return response()->json(['success' => false, 'message' => 'User Not Found'], 200);
        }
    }

    public function userSearch($perpage, $query)
    {
        $search_user = User::where([['deleted_status', '!=', 1],['name', 'like', '%' . $query . '%']])
            ->orWhere([['deleted_status', '!=', 1],['email', 'like', '%' . $query . '%']])
            ->orWhere([['deleted_status', '!=', 1],['phone_number', 'like', '%' . $query . '%']])
            ->paginate($perpage);

        if ($search_user) {
            return response()->json($search_user, 200);
        } else {
            return response()->json(['success' => false, 'message' => 'Search User Not Available'], 200);
        }
    }

    public function userPriceViewStatusUpdate(Request $request)
    {
        $userUpdate = User::where('id', $request->userId)->first();
        if ($userUpdate) {
            $userUpdate->price_view = $request->price_view;
            $userUpdate->save();

            return response()->json(['success' => 'User Price View Status Update Successfully', 'price_view' => $request->price_view], 200);
        } else {
            return response()->json(['error' => 'User Price View Status Update Error'], 200);
        }
    }

    public function userStatusUpdate(Request $request)
    {
        $userUpdate = User::where('id', $request->userId)->first();
        if ($userUpdate) {
            $userUpdate->status = $request->status;
            $userUpdate->save();

            return response()->json(['success' => 'User Status Update Successfully', 'status' => $request->status], 200);
        } else {
            return response()->json(['error' => 'User Status Update Error'], 200);
        }
    }

    public function userDeleteUpdate(Request $request)
    {
        $delete = User::where('id', $request->id)->delete();
//        $delete = User::where('id', $request->id)->first();
        if ($delete) {
//            $delete->deleted_status = 1;
//            $delete->save();
            return response()->json(['success' => 'User Delete done Successfully'], 200);
        } else {
            return response()->json(['error' => 'User delete time error occurs'], 200);
        }
    }

}
