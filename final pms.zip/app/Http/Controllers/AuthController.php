<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{

    public function sessionStatus()
    {
        if (Auth::user()) {
            date_default_timezone_set('Asia/Kolkata');

            $Ul = base64_encode(Auth::user()->id) . '-' . base64_encode(Auth::user()->role_id) . '-' . base64_encode(Auth::user()->avatar);
            setcookie('UL', $Ul, time() + 3600 * 72, '/');
            setcookie('UL_Name', \auth()->user()->name, time() + 3600 * 72, '/');
            return response()->json(['success' => true, 'message' => 'User LogIn', 'userRole' => Auth::user()->role_id], 200);
        } else {
            Auth::logout();
            setcookie('UL', "", time() + 3600, '/');
            setcookie('UL_Name', '', time() + 3600 * 72, '/');
            return response()->json(['success' => false, 'message' => 'User Logout'], 200);
        }
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'min:3']
        ]);

        if (Auth::attempt($request->only('email', 'password'))) {

            if (Auth::user()->deleted_status === 1) {
                Auth::logout();
                setcookie('UL', '', time() + 3600 * 72, '/');
                setcookie('UL_Name', '', time() + 3600 * 72, '/');
                return response()->json(['success' => false, 'message' => 'Email deleted You don\'t have access. Please reach out to management.'], 200);
            }

            if (Auth::user()->status === 0) {
                Auth::logout();
                setcookie('UL', '', time() + 3600 * 72, '/');
                setcookie('UL_Name', '', time() + 3600 * 72, '/');
                setcookie('action', '', time() + 3600 * 72, '/');
                return response()->json(['success' => false, 'message' => 'Email inactivated You don\'t have access. Please reach out to management.'], 200);
            }

            if (Auth::user()->status === 2) {
                Auth::logout();
                setcookie('UL', '', time() + 3600 * 72, '/');
                setcookie('UL_Name', '', time() + 3600 * 72, '/');
                return response()->json(['success' => false, 'message' => 'Email deleted You don\'t have access. Please reach out to management.'], 200);
            }

            if (Auth::user()->deleted_status === 0 && Auth::user()->status === 1) {
                date_default_timezone_set('Asia/Kolkata');
                $Ul = base64_encode(Auth::user()->id) . '-' . base64_encode(Auth::user()->role_id) . '-' . base64_encode(Auth::user()->avatar);
                setcookie('UL', $Ul, time() + 3600 * 72, '/');
                setcookie('UL_Name', \auth()->user()->name, time() + 3600 * 72, '/');
                return response()->json(['success' => true, 'message' => 'welcome... Login Successfully', Auth::user()], 200);
            }
        }
        throw ValidationException::withMessages([
            'success' => false,
            'email' => 'The provided credentials are incorrect.',
        ]);
    }

    public function logout()
    {
        Auth::logout();
        setcookie('UL', "", time() + 3600, '/');
        setcookie('UL_Name', '', time() + 3600 * 72, '/');
        return response()->json(['success' => true, 'message' => 'Successfully Logout'], 200);
    }

    public function getAdminProfile()
    {
        $user = User::where(['id' => \auth()->user()->id, 'status' => 1, 'deleted_status' => 0])->first();
        if ($user) {
            return response()->json(['success' => true, 'user' => $user], 200);
        } else {
            return response()->json(['success' => false], 200);
        }
    }

    public function adminProfileUpdate(Request $request)
    {
        $request->validate([
            'name' => ['required'],
            'email' => ['required', 'email'],
            'phone_number' => ['required'],
        ]);

        $emailChange = '';
        $passwordChange = '';

        $userProfileUpdate = User::where('id', auth()->user()->id)->first();
        $userProfileUpdate->name = $request->name;
        $userProfileUpdate->phone_number = $request->phone_number;

        if ($userProfileUpdate->email !== $request->email) {
            if (sizeof(User::where('email', '=', $request->email)->get()) > 0) {
                return response()->json(['success' => false, 'message' => 'User email already exists'], 200);
            } else {
                if ($userProfileUpdate->email !== $request->email) {
                    $userProfileUpdate->email = $request->email;
                    $emailChange = 'Email was successfully changed';
                }
            }
        }

        if ($request->password !== null) {
            $this->validate($request, [
                'password' => 'required',
                'password_confirmation' => 'required'
            ]);
            if ($request->password === $request->password_confirmation) {
                if (!Hash::check($request->password, $userProfileUpdate->password)) {
                    $userProfileUpdate->password = bcrypt($request->password);
                    $passwordChange = 'Password was successfully changed';
                } else {
                    return response()->json(['success' => false, 'message' => 'Password is similar as previous, create the unique password'], 200);
                }
            } else {
                return response()->json(['success' => false, 'message' => 'Password and confirm password does not match'], 200);
            }
        }

        $fileNameToStore = '';
        if ($request->hasFile('profile_image')) {
            $this->validate($request, ['profile_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048']);

            if ($userProfileUpdate->avatar !== 'avatar/avatar.png') {
                if (Storage::exists('public/' . $userProfileUpdate->avatar)) {
                    Storage::delete('public/' . $userProfileUpdate->avatar);
                }
            }
            $images_cover = $request->file('profile_image');
            $fileNamewithExt = $images_cover->getClientOriginalName();  // 1. image filename with extension
            $fileName = pathinfo($fileNamewithExt, PATHINFO_FILENAME);  //2. get profile_image name
            $fileExtension = $images_cover->getClientOriginalExtension();   //3. get profile_image extension
            $fileNameToStore = 'avatar' . md5('avatar_' . date('Y_m_d_Hi', time())) . '.' . $fileExtension;    //4. combinefile name and extension
            $path = $images_cover->storeAs('public/avatar/', $fileNameToStore); // upload profile_image name
        } else {
            $fileNameToStore = 'avatar.png';
        }

        $userProfileUpdate->avatar = 'avatar/' . $fileNameToStore;

        $userProfileUpdate->save();

        $userProfileUpdateInfo = User::where('id', '=', $userProfileUpdate->id)->first();

        $Ul = base64_encode($userProfileUpdateInfo->id) . '-' . base64_encode($userProfileUpdateInfo->role_id) . '-' . base64_encode($userProfileUpdateInfo->avatar);
        setcookie('UL', $Ul, time() + 3600 * 72, '/');
        setcookie('UL_Name', $userProfileUpdateInfo->name, time() + 3600 * 72, '/');

        if ($emailChange !== '' && $passwordChange !== '') {
            return response()->json(['success' => true, 'message' => 'Email and password updated successfully', 'adminInfo' => $userProfileUpdateInfo], 200);
        } elseif ($passwordChange !== '') {
            return response()->json(['success' => true, 'message' => 'Password updated successfully', 'adminInfo' => $userProfileUpdateInfo], 200);
        } elseif ($emailChange !== '') {
            return response()->json(['success' => true, 'message' => 'Email updated successfully', 'adminInfo' => $userProfileUpdateInfo], 200);
        } else {
            return response()->json(['success' => true, 'message' => 'Profile information updated successfully', 'adminInfo' => $userProfileUpdateInfo], 200);
        }


        //todo: ==============
        // return $request;
        // 24 H
        // 1440 M
        // 86400 S 1 day
        // 1 hour - 3600 second
    }
}
