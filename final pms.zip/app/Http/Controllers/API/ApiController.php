<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\ChinaPriceUser;
use App\Models\Product;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ApiController extends Controller
{
    //
    public function register(Request $request)
    {
        Log::Info(json_encode($request->all()));
        $validator = Validator::make($request->all(), [
            'name' => ['required'],
            'password' => ['required', 'min:3'],
            'phone_number' => ['required', 'digits:10', 'unique:users'],
            'fcm_id' => ['required'],
        ]);


        if ($validator->fails()) {
            return response()->json($validator->errors(), 401);
        }

        //        <PRE>Array
        //        (
        //            [name] => vish
        //            [phone_number] => 8530191950
        //            [fcm_id] => vish_123
        //            [password] => 123
        //          )

        $user = new User();
        $user->role_id = 1;
        $user->name = $request->name;
        $user->password = Hash::make($request->password);
        $user->phone_number = $request->phone_number;
        $user->fcm_id = $request->fcm_id;
        $user->avatar = 'avatar/avatar.png';
        $user->status = 0;
        $user->created_at = Carbon::now();
        $user->updated_at = Carbon::now();
        $user->save();

//        return response()->json(['success' => true, 'message' => 'User Register Successfully'], 200);
        return response()->json(['success' => true, 'message' => 'User Register Successfully. Please note that your account is currently pending approval from our administrators. Once your account has been reviewed and approved, you can login.'], 200);
    }

    public function login(Request $request)
    {

        Log::Info(json_encode($request->all()));
        $validator = Validator::make($request->all(), [
            'phone_number' => ['required', 'digits:10'],
            'password' => ['required', 'min:3']
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

//        if(!$token = auth()->attempt($validator->validated())){
        if(!$token = Auth::guard('api')->attempt($validator->validated())){
            return response()->json(['error'=>'Login Fail, Please Check Data']);
        }

        $user = User::where([['phone_number', '=', $request->phone_number],['deleted_status', '!=', 1]])->select('id','name','phone_number','status')->first();
        if ($user->status === 0) {
            setcookie('UL', '', time() + 3600 * 72, '/');
            setcookie('UL_Name', '', time() + 3600 * 72, '/');
            setcookie('action', '', time() + 3600 * 72, '/');
            return response()->json(['success' => false, 'message' => 'User inactivated You don\'t have access. Please reach out to management.'], 200);
        }
//        $user->fcm_id = $request->fcm_id;
//        $user->save();
//        if (!$user) {
//            return response()->json(['success' => false, 'message' => 'Login Fail, please check phone number']);
//        }
//        if (!Hash::check($request->password, $user->password)) {
//            return response()->json(['success' => false, 'message' => 'Login Fail, pls check password']);
//        }

        return response()->json([
            'success' => true,
            'message' => 'welcome... Login Successfully',
            'token' => $token,
            'token_type'=>'Bearer',
//            'expires_in'=>\auth('api')->factory()->getTTL()*60,
            'user_id' => $user->id,
            'name' => $user->name,
            'phone_number' => $user->phone_number,
        ], 200);
    }

    public function categories()
    {
        $categories = Category::where([['status','!=',0],['deleted_status', '!=', 1]])->select('id', 'name')->get();
        if(count($categories) > 0){
            return response()->json([
                'success' => true,
                'categories' => $categories,
            ], 200);
        }else{
            return response()->json(['success' => false, 'message' => 'Category Not Exists.'], 200);
        }
    }
    public function products(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => ['required'],
            'category_id' => ['required'],
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        $products = Product::where([['status','!=',0],['deleted_status', '!=', 1],['category_id', '=', $request->category_id]])->select('id', 'name', 'qty', 'price', 'china_price','tag', 'description', 'image')->get();
        if(count($products) > 0){
            foreach ($products as &$product){
                if ($request->user_id) {
                    $user = User::where('id', '=', $request->user_id)->select('id', 'price_view','phone_number')->first();
                }
                if ($user->price_view == 0) {
                    unset($product['price']);
                }
                $chinaPriceUsers = ChinaPriceUser::where('deleted_at', '=', null)->get();
                $chinaPriceUserPN = [];
                foreach ($chinaPriceUsers as $chinaPriceUser){
                    array_push($chinaPriceUserPN,$chinaPriceUser->phone_number);
                }
//                echo "<PRE>";print_r($chinaPriceUserPN);die;
                if(!in_array($user->phone_number,$chinaPriceUserPN)){
                    unset($product['china_price']);
                }

                $product['image'] = "https://skilltocode.com/storage/" . $product['image'];
            }
            return response()->json([
                'success' => true,
                'products' => $products,
            ], 200);
        }else{
            return response()->json(['success' => false, 'message' => 'Product Not Exists.'], 200);
        }


//        if ($request->user_id) {
//            $user = User::where('id', '=', $request->user_id)->select('id','price_view')->first();
//            if ($user) {
//
//
//
//
//            }else{
//                return response()->json(['success' => false, 'message' => 'Please check user id.'], 200);
//            }
//        }

    }
}
