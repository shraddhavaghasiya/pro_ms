<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class _ProductController extends Controller
{

    public function index(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'phone_number' => ['required', 'digits:10'],
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        if ($request->phone_number) {
            $user = User::where('phone_number', '=', $request->phone_number)->select('id','name', 'phone_number')->first();
            if ($user) {
                if ($user->price_view == 1) {
                    $products = Product::where('user_id', $user->id)->select('id', 'name', 'qty', 'price', 'tag', 'description', 'image')->get();
                } else {
                    $products = Product::where('user_id', $user->id)->select('id', 'name', 'qty', 'tag', 'description', 'image')->get();
                }
                if($request->name && $request->fcm_id){
                    if ($request->name == $user->name && $request->fcm_id == $user->fcm_id) {
                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }else if($request->name !== $user->name && $request->fcm_id !== $user->fcm_id){
                        $user->name = $request->name;
                        $user->fcm_id = $request->fcm_id;
                        $user->save();

                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }else if($request->name !== $user->name){
                        $user->name = $request->name;
                        $user->save();

                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }else if($request->fcm_id !== $user->fcm_id){
                        $user->fcm_id = $request->fcm_id;
                        $user->save();

                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }
                    return response()->json($response, 200);
                }elseif ($request->name){
                    if ($request->name == $user->name) {
                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }else if($request->name !== $user->name){
                        $user->name = $request->name;
                        $user->save();

                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }
                    return response()->json($response, 200);
                }elseif ($request->fcm_id){
                    if ($request->fcm_id == $user->fcm_id) {
                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }else if($request->fcm_id !== $user->fcm_id){
                        $user->fcm_id = $request->fcm_id;
                        $user->save();

                        $response = [
                            'user' => $user,
                            'products' => $products,
                        ];
                    }
                    return response()->json($response, 200);
                }

            }else{
//                $user = new User();
//                $user->role_id = 1;
//                $user->phone_number = $request->phone_number;
//                $user->name = $request->name;
//                $user->fcm_id = $request->fcm_id;
//                $user->status = 1;
//                $user->save();
//                if ($user->price_view == 1) {
//                    $products = Product::where('user_id', $user->id)->select('id', 'name', 'qty', 'price', 'tag', 'description')->get();
//                } else {
//                    $products = Product::where('user_id', $user->id)->select('id', 'name', 'qty', 'tag', 'description')->get();
//                }
//
//                $response = [
//                    'user' => $user,
//                    'products' => $products,
//                ];
//                return response()->json($response, 200);
                return response()->json(['success' => false, 'message' => 'Please check your phone number.'], 200);
            }
        }
    }

    public function register(Request $request){
//        echo "<PRE>";print_r($request->all());die;
        $validator = Validator::make($request->all(), [
            'name' => ['required'],
            'password' => ['required', 'min:3'],
            'phone_number' => ['required', 'digits:10', 'unique:users'],
//            'phone_number' => ['required', 'digits:10', 'exists:users', 'unique:users'],
            'fcm_id' => ['required'],
        ]);


        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        //        <PRE>Array
        //        (
        //            [name] => vish
        //            [phone_number] => 8530191950
        //            [fcm_id] => vish_123
        //            [email] => vish@gmail.com
        //            [password] => 123
        //          )

        $user = new User();
        $user->role_id = 1;
        $user->name = $request->name;
        $user->password = Hash::make($request->password);
        $user->phone_number = $request->phone_number;
        $user->fcm_id = $request->fcm_id;
        $user->avatar = 'avatar/avatar.png';
        $user->status = 1;
        $user->save();

//        User::create([
//            'role_id' => '1',
//            'name' => $request->name,
//            'phone_number' => $request->phone_number,
//            'fcm_id' => $request->fcm_id,
//            'email' => $request->email,
//            'password' => Hash::make($request->password),
//            'avatar' => 'avatar/avatar.png',
//            'status' => '1',
//            'deleted_status' => '0'
//        ]);
        return response()->json(['success' => true, 'message' => 'User Register Successfully'], 200);
    }
}
