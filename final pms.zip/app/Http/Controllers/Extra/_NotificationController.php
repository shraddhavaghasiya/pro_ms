<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;

class _NotificationController extends Controller
{
    //
    function sendNotificationToOneSignal($title, $message) {
        $appId = env('ONE_SIGNAL_APP_ID');
        $restApiKey = env('ONE_SIGNAL_AUTH_KEY');

        $content = [
            'app_id' => $appId,
            'included_segments' => ['All'],
            'headings' => ['en' => $title],
            'contents' => ['en' => $message],
        ];

        $client = new Client([
            'headers' => [
                'Authorization' => 'Basic ' . $restApiKey,
                'Content-Type' => 'application/json',
            ],
        ]);

        try {
            $response = $client->post('https://onesignal.com/api/v1/notifications', [
                'json' => $content,
            ]);

            return $response->getBody()->getContents();
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public function sendNotification() {
        $title = 'New Notification';
        $message = 'Hello, this is a test notification!';

        $response = $this->sendNotificationToOneSignal($title, $message);
        // Handle the response as needed
        dd($response);
    }
}
