<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Events\SendOneSignalNotification;

class TestController extends Controller
{
    public function test()
    {
        // Add a product
        $productName = "Sample Product";
        SendOneSignalNotification::dispatch('added', $productName);

        // Edit a product
        SendOneSignalNotification::dispatch('edited', $productName);

        // Delete a product
        SendOneSignalNotification::dispatch('deleted', $productName);
        return '--';
    }
}
