<?php

namespace App\Listeners;

use App\Events\SendOneSignalNotification;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IntegrationController;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

/**
 * Class OneSignalNotificationListener
 * @package App\Listeners
 */
class OneSignalNotificationListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * @param SendOneSignalNotification $event
     */
    public function handle(SendOneSignalNotification $event)
    {
        $action = $event->action;
        $productName = $event->productName;
        IntegrationController::sendOnesignalNotification($action, $productName);
    }
}
