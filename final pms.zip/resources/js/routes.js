import NotFoundComponent from "./components/backend/common/NotFoundComponent";
import ComingSoon from "./components/frontend/pages/comingsoon";

import login from "./components/frontend/pages/auth/login";
import Dashboard from "./components/backend/admin/pages/dashboard/Dashboard";
import adminUserProfile from "./components/backend/admin/pages/profile/userProfile";

import ProductList from "./components/backend/admin/pages/products/ProductList";
import ProductAdd from "./components/backend/admin/pages/products/ProductAdd";
import ProductEdit from "./components/backend/admin/pages/products/ProductEdit";
import ProductView from "./components/backend/admin/pages/products/ProductView";

import UserList from "./components/backend/admin/pages/users/UserList";

export default [
    {
        path: '*',
        component: NotFoundComponent
    },
    {
        path: '/root',
        name: 'Root',
        component: ComingSoon,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    if (response.data.userRole === 1) {
                        next({name: 'user_contacts_list'})
                        // next()
                    } else if (response.data.userRole === 2) {
                        next({name: 'employee_user_profile'});
                    }
                } else if (response.data.success === false) {
                    next()
                }
            }).catch(() => {
                next()
            })
        },
    },
    {
        path: '/',
        name: 'Login',
        component: login,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next({name: 'dashboard'});
                } else if (response.data.success === false) {
                    next();
                }
            }).catch(() => {
                next()
            })
        },
    },
    {
        path: '/dashboard',
        name: 'dashboard',
        component: Dashboard,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next();
                } else if (response.data.success === false) {
                    next({name: 'login'});
                }
            }).catch(() => {
                next({name: 'login'});
            })
        },
    },

    {
        path: '/admin-user-profile',
        name: 'admin_user_profile',
        component: adminUserProfile,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next();
                } else if (response.data.success === false) {
                    next({name: 'Login'})
                }
            }).catch(() => {
                next({name: 'Login'})
            })
        },
    },

    {
        path: "/user-list",
        name: 'user_list',
        component: UserList,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next();
                } else if (response.data.success === false) {
                    next({name: 'login'});
                }
            }).catch(() => {
                next({name: 'login'});
            })
        },
    },

    {
        path: "/product-list",
        name: 'product_list',
        component: ProductList,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next();
                } else if (response.data.success === false) {
                    next({name: 'login'});
                }
            }).catch(() => {
                next({name: 'login'});
            })
        },
    },
    {
        path: "/product-add",
        name: 'product_add',
        component: ProductAdd,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next();
                } else if (response.data.success === false) {
                    next({name: 'login'});
                }
            }).catch(() => {
                next({name: 'login'});
            })
        },
    },
    {
        path: '/product-edit/:Pid',
        name: 'product_edit',
        component: ProductEdit,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next();
                } else if (response.data.success === false) {
                    next({name: 'login'});
                }
            }).catch(() => {
                next({name: 'login'});
            })
        },
    },
    {
        path: '/product-view/:Pid',
        name: 'product_view',
        component: ProductView,
        beforeEnter: (to, form, next) => {
            axios.get('/sessionStatus').then((response) => {
                if (response.data.success === true) {
                    next();
                } else if (response.data.success === false) {
                    next({name: 'login'});
                }
            }).catch(() => {
                next({name: 'login'});
            })
        },
    },
]
