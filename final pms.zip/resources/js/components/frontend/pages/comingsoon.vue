<script>
import appConfig from "../../../app.config.json";

/**
 * Coming-soon component
 */
export default {
    name: 'comingsoon',
    layout: "auth",
    page: {
        title: "Coming-soon",
        meta: [
            {
                name: "description",
                content: appConfig.description,
            },
        ],
    },
    data() {
        return {
            title: "Coming-soon",
            start: "",
            end: "",
            interval: "",
            days: "",
            minutes: "",
            hours: "",
            seconds: "",
            starttime: "Mar 24, 2020 15:37:25",
            endtime: "Aug 12, 2021 16:37:25",
        };
    },
    mounted() {
        // document.body.classList.add('authentication-bg')

        this.start = new Date(this.starttime).getTime();
        this.end = new Date(this.endtime).getTime();
        // Update the count down every 1 second
        this.timerCount(this.start, this.end);
        this.interval = setInterval(() => {
            this.timerCount(this.start, this.end);
        }, 1000);
    },
    methods: {
        timerCount: function (start, end) {
            // Get todays date and time
            var now = new Date().getTime();

            // Find the distance between now an the count down date
            var distance = start - now;
            var passTime = end - now;

            if (distance < 0 && passTime < 0) {
                clearInterval(this.interval);
                return;
            } else if (distance < 0 && passTime > 0) {
                this.calcTime(passTime);
            } else if (distance > 0 && passTime > 0) {
                this.calcTime(distance);
            }
        },
        calcTime: function (dist) {
            // Time calculations for days, hours, minutes and seconds
            this.days = Math.floor(dist / (1000 * 60 * 60 * 24));
            this.hours = Math.floor(
                (dist % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
            );
            this.minutes = Math.floor((dist % (1000 * 60 * 60)) / (1000 * 60));
            this.seconds = Math.floor((dist % (1000 * 60)) / 1000);
        },
    },
};
</script>

<template>
    <div>
        <div class="home-btn d-none d-sm-block mt-2">
            <router-link to="/login" class="text-dark">
                <i class="mdi mdi-login-variant h4">Sign In</i>
            </router-link>
        </div>
        <div class="home-btn d-none d-sm-block mt-5">
            <router-link to="/register" class="text-dark">
                <i class="mdi mdi-login-variant h4">Sign Up</i>
            </router-link>
        </div>
        <div class="pt-sm-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <router-link to="/" class="mb-5 d-block auth-logo">
                                <h1 class="text-primary">Employee Management System</h1>
                            </router-link>

                            <h4 class="mt-5">Let's get started with Employee Management System</h4>
                            <!--                            <p class="text-muted">
                                                            It will be as simple as Occidental in fact it will be
                                                            Occidental.
                                                        </p>-->

                            <div class="row justify-content-center mt-5">
                                <div class="col-lg-4 col-sm-5">
                                    <div class="maintenance-img">
                                        <img
                                            src="/assets/images/rocket-lanch.gif"
                                            alt
                                            class="img-fluid mx-auto d-block"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div class="row justify-content-center mt-5">
                                <div class="col-lg-10">
                                    <div data-countdown="2020/12/31" class="counter-number">
                                        <div class="coming-box">
                                            {{ days }}
                                            <span>Days</span>
                                        </div>
                                        <div class="coming-box">
                                            {{ hours }}
                                            <span>Hours</span>
                                        </div>
                                        <div class="coming-box">
                                            {{ minutes }}
                                            <span>Minutes</span>
                                        </div>
                                        <div class="coming-box">
                                            {{ seconds }}
                                            <span>Seconds</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- end col-->
                            </div>
                            <!-- end row-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
