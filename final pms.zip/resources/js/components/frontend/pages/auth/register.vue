<template>
    <div>
        <div class="home-btn d-none d-sm-block">
            <router-link to="/" class="text-dark">
                <i class="mdi mdi-home-variant h2"></i>
            </router-link>
        </div>
        <loader-component :is-visible="isLoading"></loader-component>
        <div class="account-pages my-5 pt-sm-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <router-link to="/" class="mb-5 d-block auth-logo">
                                <h1 class="text-primary">Employee Management System</h1>
                            </router-link>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="card">
                            <div class="card-body p-4">
                                <div class="text-center mt-2">
                                    <h5 class="text-primary">Register Account</h5>
                                    <p class="text-muted">Get your free Employee Management System account now.</p>
                                </div>
                                <div class="p-2 mt-4">
                                    <b-alert
                                        v-model="isAuthError"
                                        variant="danger"
                                        class="mt-3"
                                        dismissible>
                                        {{ authError }}
                                    </b-alert>
                                    <b-form @submit.prevent="tryToSignUp">
                                        <b-form-group
                                            id="f_name"
                                            class="mb-3"
                                            label="First Name"
                                            label-for="f_name">
                                            <b-form-input
                                                id="f_name"
                                                v-model="f_name"
                                                type="text"
                                                placeholder="First Name"
                                                :class="{ 'is-invalid': submitted && $v.f_name.$error}">
                                            </b-form-input>
                                            <div
                                                v-if="submitted && $v.f_name.$error"
                                                class="invalid-feedback">
                                                <span v-if="!$v.f_name.required">First Name is required.</span>
                                                <span v-if="!$v.f_name.alpha">Please enter valid first name.</span>
                                            </div>
                                        </b-form-group>

                                        <b-form-group
                                            id="m_name"
                                            class="mb-3"
                                            label="Middle Name"
                                            label-for="m_name">
                                            <b-form-input
                                                id="m_name"
                                                v-model="m_name"
                                                type="text"
                                                placeholder="Middle Name"
                                                :class="{ 'is-invalid': submitted && $v.m_name.$error}">
                                            </b-form-input>
                                            <div
                                                v-if="submitted && $v.m_name.$error"
                                                class="invalid-feedback">
                                                <span v-if="!$v.m_name.required">Middle name is required.</span>
                                                <span v-if="!$v.m_name.alpha">Please enter valid middle name.</span>
                                            </div>
                                        </b-form-group>


                                        <b-form-group
                                            id="l_name"
                                            class="mb-3"
                                            label="Last Name"
                                            label-for="l_name">
                                            <b-form-input
                                                id="l_name"
                                                v-model="l_name"
                                                type="text"
                                                placeholder="Last Name"
                                                :class="{ 'is-invalid': submitted && $v.l_name.$error}">
                                            </b-form-input>
                                            <div
                                                v-if="submitted && $v.l_name.$error"
                                                class="invalid-feedback">
                                                <span v-if="!$v.l_name.required">Last Name is required.</span>
                                                <span v-if="!$v.l_name.alpha">Please enter valid last name.</span>
                                            </div>
                                        </b-form-group>

                                        <b-form-group
                                            id="email"
                                            class="mb-3"
                                            label="Email"
                                            label-for="email">
                                            <b-form-input
                                                id="email"
                                                v-model="email"
                                                type="text"
                                                placeholder="Enter email"
                                                :class="{ 'is-invalid': submitted && $v.email.$error}">
                                            </b-form-input>
                                            <div
                                                v-if="submitted && $v.email.$error"
                                                class="invalid-feedback">
                                                <span v-if="!$v.email.required">Email is required.</span>
                                                <span v-if="!$v.email.email">Please enter valid email.</span>
                                            </div>
                                        </b-form-group>

                                        <!--                                            <label for="password">Password</label>-->
                                        <b-form-group
                                            id="password"
                                            class="mb-3"
                                            label="Password"
                                            label-for="password">
                                            <b-form-input
                                                id="password"
                                                v-model="password"
                                                type="password"
                                                placeholder="Enter password"
                                                :class="{'is-invalid': submitted && $v.password.$error}"
                                            ></b-form-input>
                                            <div
                                                v-if="submitted && $v.password.$error"
                                                class="invalid-feedback">
                                                <span v-if="!$v.password.required">Password is required.</span>
                                                <span v-if="!$v.password.minLength">Please enter max 3 length of password.</span>
                                            </div>

                                            <div v-if="submitted && $v.phone_number.$error"
                                                 class="invalid-feedback">
                                                <!--                                                Password is required. !$v.password.required-->
                                            </div>
                                        </b-form-group>
                                        <div class="mt-4 text-center">
                                            <b-button type="submit" variant="primary" class="w-sm">Sign Up</b-button>
                                        </div>

                                        <div class="mt-4 text-center">
                                            <p class="mb-0">
                                                Already have an account ?
                                                <router-link
                                                    to="/login"
                                                    class="fw-medium text-primary">
                                                    Login
                                                </router-link>
                                            </p>
                                        </div>
                                    </b-form>
                                </div>
                                <!-- end card-body -->
                            </div>
                            <!-- end card -->
                        </div>
                        <div class="mt-5 text-center">
                            <p>
                                © {{ new Date().getFullYear() }} Employee Management System. Crafted with
                                <i class="mdi mdi-heart text-danger"></i>
                            </p>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>
    </div>
</template>

<script>
import {required, email, alpha, decimal, minLength} from "vuelidate/lib/validators";
import LoaderComponent from "../../../backend/common/LoaderComponent";
import {bus} from '../../../../app';

export default {
    name: 'register',
    components: {LoaderComponent},
    data() {
        return {
            isLoading: false,

            f_name: '',
            m_name: '',
            l_name: '',
            email: '',
            password: '',

            submitted: false,
            authError: null,
            isAuthError: false,
        };
    },
    validations: {
        f_name: {
            required,
            alpha,
        },
        m_name: {
            required,
            alpha,
        },
        l_name: {
            required,
            alpha,
        },
        email: {
            required,
            email,
        },
        password: {
            required,
            minLength: minLength(3),
        },
    },
    mounted() {
        document.body.classList.add("authentication-bg");
    },
    methods: {
        tryToSignUp() {
            this.submitted = true;
            // stop here if form is invalid
            this.$v.$touch();

            if (this.$v.$invalid) {
                return;
            } else {
                var self = this;
                self.isLoading = true;
                axios.post(self.bUrl + '/register', {
                    f_name: this.f_name,
                    m_name: this.m_name,
                    l_name: this.l_name,
                    email: this.email,
                    password: this.password,
                }).then(function (response) {
                    console.log(JSON.stringify(response));
                    if (response.data.success === true) {
                        self.showToast(response.data.message, 'success');
                        self.isLoading = false;
                        console.log(response.data);
                        self.$router.push('/login');
                    } else {
                        self.showToast(response.data.message, 'error');
                        self.isLoading = false;
                    }
                }).catch(function (e) {
                    console.log(e.response.data.errors);
                    // console.log(typeof e.response.data.errors.email)
                    // console.log(typeof e.response.data.errors.phone_number)
                    self.isLoading = false;
                    if (typeof e.response.data.errors.email !== 'undefined') {
                        if (typeof e.response.data.errors.email[0] !== 'undefined') {
                            self.showToast('The email has already been taken', 'error');
                        }
                    }
                    if (typeof e.response.data.errors.phone_number !== 'undefined') {
                        if (typeof e.response.data.errors.phone_number[0] !== 'undefined') {
                            self.showToast('The phone number has already been taken', 'error');
                        }
                    }
                    // self.showToast(e.response.data.errors, 'error');
                    self.showToast('Register Error, pls check Fields', 'error');
                });
            }
        },
    },
};
</script>

<style lang="scss" module></style>
