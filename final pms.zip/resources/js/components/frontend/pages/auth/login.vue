<template>
    <div>
        <div class="home-btn d-none d-sm-block">
            <router-link to="/" class="text-dark">
                <i class="mdi mdi-home-variant h2"></i>
            </router-link>
        </div>
        <loader-component :is-visible="isLoading"></loader-component>
        <div class="account-pages my-5 pt-sm-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <router-link to="/" class="mb-5 d-block auth-logo">
                                <h1 class="text-primary">Product Management System</h1>
                            </router-link>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="card">
                            <div class="card-body p-4">
                                <div class="text-center mt-2">
                                    <h5 class="text-primary">Welcome Back !</h5>
                                    <p class="text-muted">Sign in to continue to Product Management System.</p>
                                </div>
                                <div class="p-2 mt-4">
                                    <b-alert
                                        v-model="isAuthError"
                                        variant="danger"
                                        class="mt-3"
                                        dismissible>
                                        {{ authError }}
                                    </b-alert>
                                    <b-form @submit.prevent="tryToLogIn">
                                        <b-form-group
                                            id="input-group-1"
                                            class="mb-3"
                                            label="Email"
                                            label-for="input-1">
                                            <b-form-input
                                                id="input-1"
                                                v-model="email"
                                                type="text"
                                                placeholder="Enter email"
                                                :class="{ 'is-invalid': submitted && $v.email.$error}">
                                            </b-form-input>
                                            <div
                                                v-if="submitted && $v.email.$error"
                                                class="invalid-feedback">
                                                <span v-if="!$v.email.required">Email is required.</span>
                                                <span v-if="!$v.email.email">Please enter valid email.</span>
                                            </div>
                                        </b-form-group>

                                        <b-form-group id="input-group-2" class="mb-3">
                                            <label for="input-2">Password</label>
                                            <b-form-input
                                                id="input-2"
                                                v-model="password"
                                                type="password"
                                                placeholder="Enter password"
                                                :class="{'is-invalid': submitted && $v.password.$error}"
                                            ></b-form-input>
                                            <div v-if="submitted && !$v.password.required"
                                                 class="invalid-feedback">
                                                Password is required.
                                            </div>
                                        </b-form-group>
                                        <div class="mt-4 text-end">
                                            <b-button type="submit" variant="primary" class="w-sm">Log In</b-button>
                                        </div>
                                        <div class="mt-4 text-center">
                                            <p class="mb-0">
                                                Don't have an account ?
                                                <router-link
                                                    to="/register"
                                                    class="fw-medium text-primary">
                                                    SignUp now
                                                </router-link>
                                            </p>
                                        </div>
                                    </b-form>
                                </div>
                                <!-- end card-body -->
                            </div>
                            <!-- end card -->
                        </div>
                        <div class="mt-5 text-center">
                            <p>
                                © {{ new Date().getFullYear() }} Product Management System. Crafted with
                                <i class="mdi mdi-heart text-danger"></i>
                            </p>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>
    </div>
</template>

<script>
import {required, email, minLength} from "vuelidate/lib/validators";
import LoaderComponent from "../../../backend/common/LoaderComponent";
import {bus} from '../../../../app';

/**
 * Login component
 */
export default {
    name: 'login',
    components: {LoaderComponent},
    data() {
        return {
            isLoading: false,

            email: "admin@gmail.com",
            password: "",

            submitted: false,
            authError: null,
            tryingToLogIn: false,
            isAuthError: false,
        };
    },
    validations: {
        email: {
            required,
            email,
        },
        password: {
            required,
            // minLength: minLength(5),
        },
    },
    mounted() {
        // document.body.classList.add("authentication-bg");
    },
    methods: {
        tryToLogIn() {
            this.submitted = true;
            // stop here if form is invalid
            this.$v.$touch();

            if (this.$v.$invalid) {
                return false;
            } else {
                var self = this;
                self.isLoading = true;
                axios.post(self.bUrl + '/login', {
                    email: this.email,
                    password: this.password,
                }).then(function (response) {
                    console.log(JSON.stringify(response));
                    if (response.data.success === true) {
                        self.showToast(response.data.message, 'success');
                        self.isLoading = false;

                        console.log(response.data[0].role_id);
                        bus.$emit('loginUserStatusChanged', {
                            UserId: '1',
                            UserRoleId: response.data[0].role_id,
                        })

                        self.$router.push('/dashboard');
                        // if (response.data[0].role_id === 1) {
                        //     self.$router.push('/user-list');
                        // } else if (response.data[0].role_id === 2) {
                        //     self.$router.push('/employee-dashboard');
                        // }
                    } else {
                        self.showToast(response.data.message, 'error');
                        self.isLoading = false;
                    }
                }).catch(function (e) {
                    console.log(e.response.data.errors);
                    self.isLoading = false;
                    self.showToast('Login Error, pls check Email and Password', 'error');
                    // self.showToast(error.response, 'error');
                    // self.showToast(error.response.data.errors.email[0], 'error');
                });
            }
        },
    },
};
</script>

<style lang="scss" module></style>

