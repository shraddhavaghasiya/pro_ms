<template>
    <Layout>
        <PageHeader :title="title" :items="items"/>
        <loader-component :is-visible="isLoading"></loader-component>
        <div class="col-md-12 col-xl-12 mt-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h1 class="text-center text-capitalize text-success">Welcome to dashboard</h1>
                </div>
            </div>
        </div>
        <Stat
            :userCounts="userCounts"
            :productCounts="productCounts"
        />
    </Layout>
</template>


<script>
import Layout from "../../layouts/layout";
import PageHeader from "../../../common/page-header";
import LoaderComponent from "../../../common/LoaderComponent";
import appConfig from "../../../../../app.config.json";
import Stat from "./widgets-stat";

export default {
    name: 'Dashboard',
    page: {
        title: "Dashboard",
        meta: [
            {
                name: "description",
                content: appConfig.description,
            },
        ],
    },
    components: {
        LoaderComponent,
        PageHeader,
        Layout,
        Stat,
    },
    data() {
        return {
            title: "Dashboard",
            items: [
                {
                    text: "Dashboard",
                    href: "/",
                },
                {
                    text: "Dashboard",
                    active: true,
                },
            ],

            isLoading: false,
            userCounts : 0,
            productCounts : 0,
        };
    },
    methods: {
        getCountInfoList() {
            var self = this;
            self.isLoading = true;
            axios.get('/dashboard/count').then((responses) => {
                console.log(responses.data.success);
                if (responses.data.success === true) {
                    console.log(responses.data.usersCounts);
                    console.log(responses.data.productsCounts);

                    self.userCounts = responses.data.usersCounts
                    self.productCounts = responses.data.productsCounts
                } else {
                    console.log(responses.data.message);
                }
                self.isLoading = false;
            }).catch((error) => {
                console.log(error);
            })
        },

    },
    created() {
        this.getCountInfoList();
    }

};
</script>

<style>
</style>
