<template>
    <Layout>
        <PageHeader :title="title" :items="items"/>
        <loader-component :is-visible="isLoading"></loader-component>
        <div class="row">
            <div class="col-12" v-if="userNotFound === ''">
                <div class="row mt-4">
                    <div class="col-sm-12 col-md-6">
                        <div id="tickets-table_length" class="dataTables_length">
                            <label class="d-inline-flex align-items-center fw-normal">
                                Show&nbsp;
                                <b-form-select v-model="perPage" size="sm" :options="pageOptions">
                                </b-form-select>&nbsp;entries
                            </label>
                        </div>
                    </div>
                    <!-- Search -->
                    <div class="col-sm-12 col-md-6">
                        <div id="tickets-table_filter" class="dataTables_filter text-md-end">
                            <label class="d-inline-flex align-items-center fw-normal">
                                Search:
                                <b-form-input v-model="filter" type="search"
                                              class="form-control rounded form-control-sm ms-2"></b-form-input>
                            </label>
                        </div>
                    </div>
                    <!-- End search -->
                </div>
                <!-- Table -->
                <div class="table-responsive mb-0">
                    <b-table table-class="table table-centered datatable table-card-list"
                             thead-tr-class="bg-transparent"

                             id="my-table"
                             :busy.sync="isBusy"
                             :items="getUserInfoList"
                             :fields="fields"

                             :key="componentKey"
                             :current-page="currentPage"
                             :per-page="perPage"
                             striped
                             fixed
                             responsive="sm"
                             :filter="filter"
                             :sort-by.sync="sortBy"
                             :sort-desc.sync="sortDesc"
                             :filter-included-fields="filterOn">
                        <!--                        @filtered="onFiltered"-->

                        <template v-slot:cell(id)="data">
                            <div class="ml-2"> #{{ data.index + 1 }}</div>
                        </template>

                        <template v-slot:cell(name)="data">
                            <img v-if="data.item.avatar" :src="'./storage/'+data.item.avatar" alt
                                 class="avatar-xs rounded-circle me-2"/>
                            <div v-else class="avatar-xs d-inline-block me-2">
                                <span
                                    class="avatar-title rounded-circle bg-light text-body">{{ data.item.name.charAt(0) }}</span>
                            </div>
                            <span>{{ data.item.name }}</span>
                        </template>

                        <template v-slot:cell(status)="data">
                            <div class="badge bg-pill bg-soft-success font-size-12"
                                 :class="{'bg-soft-danger': data.item.status == '0'}">
                                                <span v-if="data.item.status === 0">
                                                    <a v-on:click="toggleUserStatus(data.index , data.item.id , 1)"
                                                       title="Click to change status active" style="cursor: pointer;">
                                                            <span class="rounded-pill">
                                                            InActive
                                                            </span>
                                                        </a>
                                                </span>
                                <span v-else>
                                                        <a v-on:click="toggleUserStatus(data.index , data.item.id , 0)"
                                                           title="Click to change status inactive"
                                                           style="cursor: pointer; ">
                                                            <span class="rounded-pill">
                                                                Active
                                                            </span>
                                                        </a>
                                                </span>
                            </div>
                        </template>

                        <template v-slot:cell(price_view)="data">
                            <div class="badge bg-pill bg-soft-success font-size-12"
                                 :class="{'bg-soft-danger': data.item.price_view == '0'}">
                                                <span v-if="data.item.price_view === 0">
                                                    <a v-on:click="togglePriceViewStatus(data.index , data.item.id , 1)"
                                                       title="Click to change status active" style="cursor: pointer;">
                                                            <span class="rounded-pill">
                                                            InActive
                                                            </span>
                                                        </a>
                                                </span>
                                <span v-else>
                                                        <a v-on:click="togglePriceViewStatus(data.index , data.item.id , 0)"
                                                           title="Click to change status inactive"
                                                           style="cursor: pointer; ">
                                                            <span class="rounded-pill">
                                                                Active
                                                            </span>
                                                        </a>
                                                </span>
                            </div>
                        </template>

                        <template v-slot:cell(action)="data">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <a class="px-2 text-danger" style="cursor: pointer;"
                                       title="Delete"
                                       @click="deleteUser(data.index, data.item.id)">
                                        <i class="uil uil-trash-alt font-size-18"></i>
                                    </a>
                                </li>
                            </ul>
                        </template>
                    </b-table>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="dataTables_paginate paging_simple_numbers float-end">
                            <ul class="pagination pagination-rounded">
                                <b-pagination
                                    v-model="currentPage"
                                    :total-rows="totalRows"
                                    :per-page="perPage"></b-pagination>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else>
                <div class="card">
                    <h3 class="text-center text-danger my-5">
                        User Not Available
                    </h3>
                </div>
            </div>
        </div>
    </Layout>
</template>

<script>
import Layout from "../../layouts/layout";
import PageHeader from "../../../common/page-header";
import appConfig from "../../../../../app.config.json";
import LoaderComponent from "../../../common/LoaderComponent";

export default {
    name: "UserList",
    components: {LoaderComponent, Layout, PageHeader},
    page: {
        title: "Users",
        meta: [
            {
                name: "description",
                content: appConfig.description,
            },
        ],
    },
    data() {
        return {
            // -----
            componentKey: 0,
            // currentUser: [],

            title: "Users",
            items: [{
                text: "Users",
            },
                {
                    text: "Users",
                    active: true,
                },
            ],

            isBusy: false,
            isLoading: false,

            userNotFound: '',

            users: [],

            totalRows: 1,
            currentPage: 1,
            perPage: 25,
            pageOptions: [2, 5, 10, 25, 50, 100],
            filter: null,

            filterOn: [],
            sortBy: "price",
            sortDesc: true,
            fields: [
                {
                    key: "id",
                    label: "Id",
                    class: "col-md-1",
                    sortable: true,
                },
                {
                    key: "name",
                    label: "User Details",
                    sortable: true,
                    class: "col-md-1 th_title_class",
                },
                {
                    key: "email",
                    sortable: true,
                    class: "col-md-1",
                },
                {
                    key: "phone_number",
                    sortable: true,
                    class: "col-md-1",
                },
                {
                    key: "status",
                    label: "Status",
                    class: "col-md-1",
                },
                {
                    key: "price_view",
                    label: "Price View",
                    class: "col-md-1",
                },
                {
                    key: "action",
                    class: "col-md-1",
                }
            ],
        };
    },

    methods: {
        deleteUser(index, id) {
            this.$swal({
                title: 'Are you sure?',
                text: "Are you sure you want to delete this item?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#89b6ea',
                cancelButtonColor: '#f37a7a',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    var self = this;
                    self.isLoading = true;
                    axios.post(self.bUrl + '/user/user-delete-update', {
                        id: id
                    }).then(function (response) {
                        if (!response.data.error) {
                            console.log(response.data);

                            self.users.splice(index, 1);
                            self.totalRows -= 1;
                            self.$swal({
                                text: response.data.success,
                                icon: "success",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                timer: 1500
                            })
                            self.isLoading = false;
                        } else {
                            console.log(response.data.error);
                            self.$swal({
                                text: response.data.error,
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            })
                            self.isLoading = false;
                        }
                        self.tableComponentKey += 1;
                        self.componentKey += 1;
                        self.isLoading = false;
                    }).catch(function (error) {
                        console.log(error);
                        self.$swal({
                            text: error,
                            icon: "error",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        })
                    });
                } else if (result.dismiss === this.$swal.DismissReason.cancel) {
                    this.$swal.fire(
                        'Cancelled',
                        'Your imaginary data is safe :)',
                        'error'
                    )
                }
            });
        },

        toggleUserStatus(i, uid, viewValue) {
            // console.log({'i': i, 'pid': pid, 'view': viewValue});
            var self = this;
            self.isLoading = true;
            axios.post(self.bUrl + '/user/user-status-update', {
                userId: uid,
                status: viewValue
            }).then(function (response) {
                console.log(JSON.stringify(response.data));
                if (!response.data.error) {
                    console.log(response.data);

                    self.users[i].status = response.data.status;
                    self.isLoading = false;
                    self.showToast(response.data.success, 'success');
                } else {
                    console.log(response.data.error);
                    self.showToast(response.data.error, 'error');
                    self.isLoading = false;
                }
            }).catch(function (error) {
                console.log(error);
                self.showToast(error, 'error');
            });
        },

        togglePriceViewStatus(i, pid, viewValue) {
            // console.log({'i': i, 'pid': pid, 'view': viewValue});
            var self = this;
            self.isLoading = true;
            axios.post(self.bUrl + '/user/user-price-view-status-update', {
                userId: pid,
                price_view: viewValue
            }).then(function (response) {
                console.log(JSON.stringify(response.data));
                if (!response.data.error) {
                    console.log(response.data);

                    self.users[i].price_view = response.data.price_view;
                    self.isLoading = false;
                    self.showToast(response.data.success, 'success');
                } else {
                    console.log(response.data.error);
                    self.showToast(response.data.error, 'error');
                    self.isLoading = false;
                }
            }).catch(function (error) {
                console.log(error);
                self.showToast(error, 'error');
            });
        },

        getUserInfoList(ctx) {
            console.log('ctx');
            if (ctx.filter === null || ctx.filter === '') {
                var self = this;
                self.isBusy = true;
                self.isLoading = true;

                let promise = axios.get('/user/admin-user-list/' + ctx.perPage + '?page=' + ctx.currentPage)
                return promise.then((responses) => {

                    // if (responses.success === true) {
                    console.log(responses);
                    console.log(responses.data.success);


                    if (responses.data.success === true) {
                        var users = responses.data.userLists.data;
                        responses.data.userLists.data.map((value, key) => {
                            self.users.push(value)
                        })

                        self.currentPage = responses.data.userLists.current_page;
                        self.totalRows = responses.data.userLists.total;

                        // console.log(self.totalRows);
                        self.isBusy = false
                        self.isLoading = false;
                        return users;

                    } else {
                        // alert('user not Found');
                        console.log(responses.data.message);
                        self.userNotFound = responses.data.message;
                    }
                    // } else {
                    //     self.isBusy = false
                    //     self.isLoading = false;
                    //     self.userNotFound = responses.data.message;
                    // }
                    self.isBusy = false
                    self.isLoading = false;
                }).catch((error) => {
                    console.log(error);
                })
            } else {
                // $search_user
                this.isBusy = true
                this.isLoading = true

                //http://crm.test/admin/admin-employee-search/10/vis?page=1
                let filterval = ctx.filter.toLowerCase();
                let promise = axios.get('/user/admin-user-search/' + this.perPage + '/' + filterval + '?page=' + ctx.currentPage)

                return promise.then((res) => {

                    console.log(res);
                    console.log('done');
                    var users = res.data.data;

                    if (res.data.data.length > 0) {
                        // alert('user Found');
                        this.users = res.data.data;
                    } else {
                        // alert('user not Found');
                        this.userNotFound = 'User not Found';
                    }

                    this.currentPage = res.data.current_page;
                    this.totalRows = res.data.total;

                    console.log(this.totalRows);
                    this.isBusy = false
                    this.isLoading = false;
                    return users;
                    // Here we could override the busy state, setting isBusy to false
                }).catch(error => {
                    // Here we could override the busy state, setting isBusy to false
                    this.isBusy = false
                    this.isLoading = false;
                    // Returning an empty array, allows table to correctly handle
                    // internal busy state in case of error
                    return []
                });
            }
        },
    },
    created() {
        this.checkIfLogged();
    },
    middleware: "authentication",
}
</script>

<style scoped>
.ellipsis {
    text-overflow: ellipsis;
    /* Required for text-overflow to do anything */
    white-space: nowrap;
    overflow: hidden;
}
</style>
