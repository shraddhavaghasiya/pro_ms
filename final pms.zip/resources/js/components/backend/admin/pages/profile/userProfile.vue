<template>
    <Layout>
        <PageHeader :title="title" :items="items"/>
        <!--Loader Add -->
        <loader-component :is-visible="isLoading"></loader-component>

        <div class="row">

            <div class="card">
                <a
                    href="javascript: void(0);"
                    class="text-dark"
                    data-toggle="collapse"
                    aria-expanded="true"
                    aria-controls="addproduct-billinginfo-collapse">
                </a>

                <b-collapse
                    data-parent="#addproduct-accordion"
                    visible
                    accordion="my-accordion"
                >
                    <div class="mt-3 p-4">
                        <form enctype="multipart/form-data" v-on:submit.prevent="saveForm">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-row mx-4">
                                        <div class="col-lg-8">
                                            <div class="form-group row">
                                                <div class="col-md-6">
                                                    <label for="name" class="ml-1 col-form-label">
                                                        Name<span
                                                        class="text-danger required">*</span></label>
                                                    <input type="text"
                                                           class="form-control"
                                                           id="name"
                                                           v-model="form.name"
                                                           maxlength="190"
                                                           placeholder="First Name" required="required">
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="email"
                                                           class="ml-1 col-form-label">Email<span
                                                        class="text-danger required">*</span></label>
                                                    <input type="email"
                                                           class="form-control"
                                                           id="email"
                                                           v-model="form.email"
                                                           maxlength="190"
                                                           placeholder="Please Enter Email"
                                                           required="required">
                                                </div>

                                            </div>

                                            <div class="col-md-12">

                                                <div class="col-md-6">
                                                    <label for="phone_number" class="ml-1 col-form-label">
                                                        Phone Number<span
                                                        class="text-danger required">*</span></label>
                                                    <input type="text"
                                                           class="form-control"
                                                           id="phone_number"
                                                           v-model="form.phone_number"
                                                           maxlength="190"
                                                           placeholder="Phone Number" required="required">
                                                </div>
                                            </div>

                                            <!--Password -->
                                            <div class="form-group row">
                                                <div class="col-md-6">
                                                    <label for="password"
                                                           class="ml-1 col-form-label">Password<span
                                                        class="text-danger required">*</span></label>
                                                    <input type="password"
                                                           class="form-control"
                                                           id="password"
                                                           v-model="form.password"
                                                           maxlength="190"
                                                           placeholder="Please Enter Password">
                                                    <span class="text-danger"
                                                          v-if="customErrors.passwordCustomError.passwordErrorShow">{{
                                                            customErrors.passwordCustomError.passwordErrorText
                                                        }}</span>
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="password_confirmation"
                                                           class="ml-1 col-form-label">Confirm
                                                        Password<span
                                                            class="text-danger required">*</span></label>
                                                    <input type="password"
                                                           class="form-control"
                                                           id="password_confirmation"
                                                           v-model="form.password_confirmation"
                                                           maxlength="190"
                                                           v-on:change="passwordValidation"
                                                           placeholder="Confirm Password">
                                                    <span class="text-danger"
                                                          v-if="customErrors.password_confirmationCustomError.password_confirmationErrorShow">{{
                                                            customErrors.password_confirmationCustomError.password_confirmationErrorText
                                                        }}</span>

                                                    <!--                                                <span class="help-block d-none text-danger"
                                                                                                          id="password_error">Password and Confirm Password Does Not Match </span>-->
                                                </div>
                                            </div>
                                        </div>

                                        <!--Todo : Image Upload Section-->


                                        <div class="col-lg-4 mt-4">
                                            <label for="userProfilePicture" class="text-center w-100 mb-4">Profile Picture</label>
                                            <div v-if="form.selected_profile_image !== ''"
                                                 class="edit-user-details__avatar m-auto"><img
                                                :src="form.selected_profile_image"
                                                alt="User Avatar">
                                                <label class="edit-user-details__avatar__change_vish">
                                                    <!--<i class="material-icons mr-1">+</i>-->
                                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                                    <!--<input id="userProfilePicture" type="file" class="d-none form-control">-->
                                                </label>
                                            </div>
                                            <div v-else class="edit-user-details__avatar m-auto">
                                                <img
                                                :src="'/storage/'+form.avatar"
                                                alt="User Avatar">
                                                <label class="edit-user-details__avatar__change_vish">
                                                    <!--<i class="material-icons mr-1">+</i>-->
                                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                                    <!--<input id="userProfilePicture" type="file" class="d-none form-control">-->
                                                </label>
                                            </div>
                                            <label
                                                class="btn btn-primary btn-sm d-table mx-auto mt-4"
                                                :class="dangerClass">
                                                <i class="material-icons"></i>
                                                Browse <input
                                                ref="upload"
                                                type="file"
                                                name="file-upload"
                                                multiple=""
                                                accept="image/jpeg, image/png"
                                                hidden
                                                v-on:change="profileImageChange">
                                            </label>
                                            <div class="text-center">
                                    <span v-if="showProfileImageError"
                                          class="text-danger text-center mt-1 mb-1">
                                        {{ profileImageErrors }}</span>
                                            </div>
                                        </div>
                                        <!--Todo : End Image Upload Section-->
                                    </div>
                                    <!--  offset-md-4 -->
                                    <div class="form-group row mb-0">
                                        <div class="col-md-12 text-center mt-4 mb-3">
                                            <button type="submit"
                                                    class="btn btn-success button-prevent-multiple-submits">
                                                Submit
                                            </button>
                                        </div>
                                    </div>

                                    <!--<div>
                                                                        <div v-for="(f , index) in form" :key=index>
                                                                            <div>
                                                                                {{ f }}
                                                                            </div>
                                                                        </div>
                                                                    </div>-->
                                </div>
                            </div>
                        </form>
                    </div>
                </b-collapse>
            </div>
        </div>
    </Layout>
</template>

<script>
import appConfig from "../../../../../app.config.json";
import {bus} from "../../../../../app";
import Layout from "../../layouts/layout";
import PageHeader from "../../../common/page-header";
import LoaderComponent from "../../../common/LoaderComponent";

export default {
    name: "adminProfile",
    components: {
        LoaderComponent,
        PageHeader,
        Layout
    },
    page: {
        title: "Admin Profile",
        meta: [
            {
                name: "description",
                content: appConfig.description,
            },
        ],
    },
    data() {
        return {
            title: "Admin Profile",
            items: [
                {
                    text: "Profile",
                },
                {
                    text: "Admin Profile",
                    active: true,
                },
            ],

            form: {
                name: '',
                email: '',
                phone_number: '',
                password: '',
                password_confirmation: '',

                avatar: '',
                profile_image: '',
                selected_profile_image: '',
            },

            isLoading: false,
            errors: [],
            showProfileImageError: '',
            profileImageErrors: '',
            dangerClass: '',

            customErrors: {
                passwordCustomError: {
                    passwordErrorShow: false,
                    passwordErrorText: '',
                },
                password_confirmationCustomError: {
                    password_confirmationErrorShow: false,
                    password_confirmationErrorText: '',
                },
            },
        }
    }, methods: {
        passwordValidation() {
            // alert('valid')
            let password = this.form.password;
            let password_confirmation = this.form.password_confirmation;


            if (password == null || password === '') {
                // alert('Birth date required');
                this.customErrors.passwordCustomError.passwordErrorShow = true;
                this.customErrors.passwordCustomError.passwordErrorText = 'password required';
                return false;
            }

            if (password_confirmation == null || password_confirmation === '') {
                // alert('joining_date date required');
                this.customErrors.password_confirmationCustomError.password_confirmationErrorShow = true;
                this.customErrors.password_confirmationCustomError.password_confirmationErrorText = 'password confirmation required';
                return false;
            }


            if (password !== null && password_confirmation !== null && password === password_confirmation) {
                this.customErrors.passwordCustomError.passwordErrorShow = false;
                this.customErrors.password_confirmationCustomError.password_confirmationErrorShow = false;
                this.customErrors.password_confirmationCustomError.password_confirmationErrorText = '';
                return true;
            } else {
                this.customErrors.passwordCustomError.passwordErrorShow = false;
                this.customErrors.password_confirmationCustomError.password_confirmationErrorShow = true;
                this.customErrors.password_confirmationCustomError.password_confirmationErrorText = 'Password and Confirm Password Does Not Match';
                return false;
            }
        },
        saveForm() {
            // alert('modal method call');
            const config = {
                headers: {'content-type': 'multipart/form-data'}
            }

            let formData = new FormData();
            formData.append('name', this.form.name);
            formData.append('email', this.form.email);
            formData.append('phone_number', this.form.phone_number);
            formData.append('password', this.form.password);
            formData.append('password_confirmation', this.form.password_confirmation);

            formData.append('old_profile_image', this.form.avatar);
            formData.append('profile_image', this.form.profile_image);
            formData.append('selected_profile_image', this.form.selected_profile_image);

            let self = this;
            if (this.form.password === this.form.password_confirmation) {
                self.isLoading = true;
                axios.post('/profile/user-profile-update', formData, config).then((response) => {
                    console.log('saved');
                    console.log(response);
                    console.log(JSON.stringify(response.data.success));
                    console.log(JSON.stringify(response.data.message));

                    if (response.data.success === false) {

                        // alert(response.data.message);
                        self.showToast(response.data.message, 'error');
                        self.isLoading = false;
                    } else if (response.data.success === true) {
                        // alert(response.data.message);
                        self.showToast(response.data.message, 'success');
                        bus.$emit('loginUserProfileUpdate', {
                            avatar: response.data.adminInfo.avatar,
                            name:
                                response.data.adminInfo.f_name + ' ' +
                                response.data.adminInfo.m_name + ' ' +
                                response.data.adminInfo.l_name
                        })
                        self.isLoading = false;
                    }
                }).catch((error) => {
                    self.errors.push(error);
                    self.showToast(error, 'error');
                })
            } else {
                this.errors.push('password and conf_password does not match');
            }
        },

        profileImageChange(event) {
            this.isLoading = true;

            const file = event.target.files[0];
            if (file) {
                var fileType = file["type"]; // file.type
                var validImageTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/svg+xml"];
                if ($.inArray(fileType, validImageTypes) < 0) {

                    // console.log(fileType);
                    this.showProfileImageError = true;
                    this.profileImageErrors = 'Invalid image format';
                    this.dangerClass = 'btn-danger';
                    this.isLoading = false;

                    // this.form.selected_profile_image = 'https://designrevision.com/demo/shards-dashboard-vue/img/0.73476783.jpg';
                    this.form.selected_profile_image = '/storage/avatar/avatar.png';
                    this.form.profile_image = '';
                    return false;
                } else {
                    if (file.size / 1024 / 1024 <= 2) {
                        this.form.selected_profile_image = URL.createObjectURL(file); // use preview
                        this.form.profile_image = event.target.files[0]; // DB STORE
                        console.log(this.form.profile_image);
                        this.showProfileImageError = false;
                        this.profileImageErrors = '';
                        this.dangerClass = '';
                        this.isLoading = false;
                    } else {
                        this.showProfileImageError = true;
                        this.profileImageErrors = 'The profile image may not be greater than 2048 kilobytes.';
                        this.dangerClass = 'btn-danger';
                        // this.form.selected_profile_image = 'https://designrevision.com/demo/shards-dashboard-vue/img/0.73476783.jpg';
                        this.form.selected_profile_image = '/storage/avatar/avatar.png';
                        this.form.profile_image = '';
                        this.isLoading = false;
                        return false;
                    }
                }
            } else {
                this.showProfileImageError = true;
                this.profileImageErrors = 'Please Select Profile Image';
                this.dangerClass = 'btn-danger';
                // this.form.selected_profile_image = 'https://designrevision.com/demo/shards-dashboard-vue/img/0.73476783.jpg';
                this.form.selected_profile_image = '/storage/avatar/avatar.png';
                this.form.profile_image = '';
                this.isLoading = false;
                return false;
            }
        },
        getUserInfo() {
            var self = this;
            self.isLoading = true;
            axios.get('/profile/get-admin-profile').then((responses) => {
                if (responses.data.success === true) {
                    // self.form = responses.data.user;
                    self.form.name = responses.data.user.name;
                    self.form.email = responses.data.user.email;
                    self.form.phone_number = responses.data.user.phone_number;
                    self.form.avatar = '/' + responses.data.user.avatar;
                }
                self.isLoading = false;
            }).catch((e) => {
                console.log(e);
            });
        }
    },
    created() {
        this.getUserInfo();
    },
}
</script>


<style scoped>
.edit-user-details__avatar {
    border-radius: 50%;
    overflow: hidden;
    position: relative;
    max-width: 7.5rem;
    /*-webkit-box-shadow: 0 2px 0 rgb(90 97 105 / 11%), 0 4px 8px rgb(90 97 105 / 12%), 0 10px 10px rgb(90 97 105 / 6%), 0 7px 70px rgb(90 97 105 / 10%);*/
    box-shadow: 0 2px 0 rgb(90 97 105 / 11%), 0 4px 8px rgb(90 97 105 / 12%), 0 10px 10px rgb(90 97 105 / 6%), 0 7px 70px rgb(90 97 105 / 10%);
}

.edit-user-details__avatar img {
    width: 100%;
}

img, svg {
    vertical-align: middle;
}

img {
    border-style: none;
}

label {
    font-weight: 400;
    display: inline-block;
}

.edit-user-details__avatar__change i {
    color: #9ea8b9;
    line-height: 7.5rem;
}

i.material-icons {
    top: 2px;
    font-size: inherit;
    position: relative;
}

.edit-user-details__avatar__change_vish {
    margin: 0;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    opacity: 0;
    position: absolute;
    text-align: center;
    border-radius: 50%;
    font-size: 1.875rem;
    background: hsla(0, 0%, 100%, .95);
    /* -webkit-transition: all .25s cubic-bezier(.27,.01,.38,1.06); */
    transition: all .25s cubic-bezier(.27, .01, .38, 1.06);
}
</style>
