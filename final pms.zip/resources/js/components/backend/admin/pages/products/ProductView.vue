<template>
    <Layout>
        <PageHeader :title="title" :items="items"/>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">

                            <div class="col-xl-5">
                                <div class="product-detail">
                                    <b-tabs pills vertical>
                                        <!--nav-wrapper-class="col-3" class="img-fluid mx-auto d-block tab-img rounded"-->

                                        <b-tab v-if="productDetail.image !== 'product_thumbnail/product_thumbnail.jpg'">
                                            <template v-slot:title>
                                                <img
                                                    :src="'../storage/' + productDetail.image"
                                                    alt="img"
                                                    class="img-thumbnail mx-auto d-block tab-img rounded"
                                                    style="height: 50px ; max-width: 50px;"
                                                />
                                            </template>
                                            <div class="product-img">
                                                <img
                                                    :src="'../storage/' + productDetail.image"
                                                    alt="img"
                                                    class="img-fluid mx-auto d-block"
                                                    style="width: 542px !important; max-height: 493px !important;"
                                                />
                                            </div>
                                        </b-tab>
                                        <b-tab v-else>
                                            <template v-slot:title>
                                                <img
                                                    :src="'../storage/' + productDetail.image"
                                                    alt="img"
                                                    class="img-thumbnail mx-auto d-block tab-img rounded"
                                                    style="height: 50px ; max-width: 50px;"
                                                />
                                            </template>
                                            <div class="product-img">
                                                <img
                                                    :src="'../storage/' + productDetail.image"
                                                    alt="img"
                                                    class="img-fluid mx-auto d-block"
                                                    style="width: 542px !important; max-height: 493px !important;"
                                                />
                                            </div>
                                        </b-tab>


                                        <b-tab v-for="(productImage , index) in productDetail.product_images"
                                               :key="index">
<!--                                            <template v-slot:title>-->
<!--                                                <img-->
<!--                                                    :src="'../storage/' + productImage.image"-->
<!--                                                    class="img-thumbnail mx-auto d-block tab-img rounded"-->
<!--                                                    style="height: 50px ; max-width: 50px;"-->
<!--                                                    alt="img"-->
<!--                                                />-->
<!--                                            </template>-->
                                            <div class="product-img">
                                                <img
                                                    :src="'../storage/' + productImage.image"
                                                    alt="img"
                                                    class="img-fluid mx-auto d-block"
                                                    style="width: 542px !important; max-height: 493px !important;"
                                                />
                                            </div>
                                        </b-tab>
                                    </b-tabs>
                                </div>
                            </div>

                            <div class="col-xl-7">
                                <div class="mt-4 mt-xl-3 pl-xl-4">
                                    <h4 class="font-size-20 mb-3">{{ productDetail.name }}</h4>
                                    <p class="text-muted mb-4">
                                        <!--{{ productDetail.description }}-->
                                        <span v-html="productDetail.description"></span>
                                    </p>
                                    <hr>
                                    <h4 class="font-size-20 mb-3">{{ productDetail.tag == "New" ? productDetail.tag : "" }}</h4>
                                    <h4 class="font-size-15 mb-3">QTY: {{ productDetail.qty }}</h4>
                                    <h5 class="mb-4 pt-4">
                                        <span class="text-danger">${{ formatPrice(productDetail.price) }}</span>
                                    </h5>

                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                </div>

                <div class="text-center">
                    <router-link to="/product-list"
                                 class="btn btn-danger">
                        <i class="uil uil-times me-1"></i>
                        Back
                    </router-link>
                </div>
                <!-- end card -->
            </div>
        </div>
        <!-- end row -->
    </Layout>
</template>
<script>
import Layout from "../../layouts/layout";
import PageHeader from "../../../common/page-header";

export default {
    name: 'ProductView',
    components: {Layout, PageHeader},
    data() {
        return {
            // productData: productData,
            productId: this.$route.params.Pid,
            productDetail: '',
            title: "Product-detail",
            items: [
                {
                    text: "Product",
                },
                {
                    text: "Product-detail",
                    active: true,
                },
            ],
        };
    },
    methods: {
        getProductInfo() {
            let product = this.productId;
            let self = this;
            axios.get('/product/admin-product-show/' + product).then(response => {
                self.productDetail = response.data.product;
            }).catch(error => {
                console.log(error);
            });
        },
    },
    mounted() {
        this.getProductInfo();

    },
    created() {
        this.checkIfLogged();
    },
};
</script>


