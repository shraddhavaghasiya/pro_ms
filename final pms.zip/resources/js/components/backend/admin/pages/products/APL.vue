<template>
    <div class="col-lg-8 col-xl-9">
        <div class="card"><!----><!---->
            <div class="card-body"><!----><!---->
                <div>
                    <div class="row">
                        <div class="col-md-6">
                            <div><h5>Showing result for "Shoes"</h5>
                                <ol class="breadcrumb p-0 bg-transparent mb-2">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Footwear</a></li>
                                    <li class="breadcrumb-item active">Shoes</li>
                                </ol>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-inline float-md-end">
                                <div class="search-box ms-2">
                                    <div class="position-relative"><input type="text"
                                                                          class="form-control bg-light border-light rounded"
                                                                          placeholder="Search..."><i
                                        class="mdi mdi-magnify search-icon"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <ul class="nav nav-tabs nav-tabs-custom mt-3 mb-2 ecommerce-sortby-list">
                        <li class="nav-item"><a class="nav-link disabled fw-medium" href="#" tabindex="-1"
                                                aria-disabled="true">Sort by:</a></li>
                        <li class="nav-item"><a class="nav-link active" href="#">Popularity</a></li>
                        <li class="nav-item"><a class="nav-link" href="#">Newest</a></li>
                        <li class="nav-item"><a class="nav-link" href="#">Discount</a></li>
                    </ul>
                    <div class="row">
                        <div class="col col-xl-4 col-sm-6">
                            <div class="product-box">
                                <div class="product-img pt-4 px-4">
                                    <div class="product-ribbon badge bg-danger"> - 20 %</div>
                                    <div class="product-wishlist"><a href="#"><i class="mdi mdi-heart-outline"></i></a>
                                    </div>
                                    <img src="/minible/vue/v-light/img/img-1.a322be45.png" alt=""
                                         class="img-fluid mx-auto d-block"></div>
                                <div class="text-center product-content p-4"><h5 class="mb-1"><a
                                    href="/minible/vue/v-light/ecommerce/product-detail/1" class="nav-link">Nike N012
                                    Shoes</a></h5>
                                    <p class="text-muted font-size-13">Gray, Shoes</p>
                                    <h5 class="mt-3 mb-0"><span class="text-muted me-2"><del>$280</del></span> $260</h5>
                                    <ul class="list-inline mb-0 text-muted product-color">
                                        <li class="list-inline-item">Colors :</li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-dark"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-light"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-primary"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col col-xl-4 col-sm-6">
                            <div class="product-box">
                                <div class="product-img pt-4 px-4">
                                    <div class="product-ribbon badge bg-danger"> - 10 %</div>
                                    <div class="product-wishlist"><a href="#"><i class="mdi mdi-heart-outline"></i></a>
                                    </div>
                                    <img src="/minible/vue/v-light/img/img-2.06a2a6e8.png" alt=""
                                         class="img-fluid mx-auto d-block"></div>
                                <div class="text-center product-content p-4"><h5 class="mb-1"><a
                                    href="/minible/vue/v-light/ecommerce/product-detail/2" class="nav-link">Adidas
                                    Running Shoes</a></h5>
                                    <p class="text-muted font-size-13">Black, Shoes</p>
                                    <h5 class="mt-3 mb-0"><span class="text-muted me-2"><del>$250</del></span> $240</h5>
                                    <ul class="list-inline mb-0 text-muted product-color">
                                        <li class="list-inline-item">Colors :</li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-danger"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-dark"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-light"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col col-xl-4 col-sm-6">
                            <div class="product-box">
                                <div class="product-img pt-4 px-4">
                                    <div class="product-ribbon badge bg-danger"> - 10 %</div>
                                    <div class="product-wishlist"><a href="#"><i class="mdi mdi-heart-outline"></i></a>
                                    </div>
                                    <img src="/minible/vue/v-light/img/img-3.11826cc7.png" alt=""
                                         class="img-fluid mx-auto d-block"></div>
                                <div class="text-center product-content p-4"><h5 class="mb-1"><a
                                    href="/minible/vue/v-light/ecommerce/product-detail/3" class="nav-link">Puma P103
                                    Shoes</a></h5>
                                    <p class="text-muted font-size-13">Purple, Shoes</p>
                                    <h5 class="mt-3 mb-0"><span class="text-muted me-2"><del>$260</del></span> $250</h5>
                                    <ul class="list-inline mb-0 text-muted product-color">
                                        <li class="list-inline-item">Colors :</li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-purple"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-light"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-dark"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col col-xl-4 col-sm-6">
                            <div class="product-box">
                                <div class="product-img pt-4 px-4">
                                    <div class="product-ribbon badge bg-danger"> - 10 %</div>
                                    <div class="product-wishlist"><a href="#"><i class="mdi mdi-heart-outline"></i></a>
                                    </div>
                                    <img src="/minible/vue/v-light/img/img-4.55912d26.png" alt=""
                                         class="img-fluid mx-auto d-block"></div>
                                <div class="text-center product-content p-4"><h5 class="mb-1"><a
                                    href="/minible/vue/v-light/ecommerce/product-detail/4" class="nav-link">Sports S120
                                    Shoes</a></h5>
                                    <p class="text-muted font-size-13">Purple, Shoes</p>
                                    <h5 class="mt-3 mb-0"><span class="text-muted me-2"><del>$240</del></span> $230</h5>
                                    <ul class="list-inline mb-0 text-muted product-color">
                                        <li class="list-inline-item">Colors :</li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-info"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-success"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col col-xl-4 col-sm-6">
                            <div class="product-box">
                                <div class="product-img pt-4 px-4">
                                    <div class="product-ribbon badge bg-danger"> - 10 %</div>
                                    <div class="product-wishlist"><a href="#"><i class="mdi mdi-heart-outline"></i></a>
                                    </div>
                                    <img src="/minible/vue/v-light/img/img-5.3eca3359.png" alt=""
                                         class="img-fluid mx-auto d-block"></div>
                                <div class="text-center product-content p-4"><h5 class="mb-1"><a
                                    href="/minible/vue/v-light/ecommerce/product-detail/5" class="nav-link">Adidas AB23
                                    Shoes</a></h5>
                                    <p class="text-muted font-size-13">Blue, Shoes</p>
                                    <h5 class="mt-3 mb-0"><span class="text-muted me-2"><del>$250</del></span> $240</h5>
                                    <ul class="list-inline mb-0 text-muted product-color">
                                        <li class="list-inline-item">Colors :</li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-dark"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-light"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-primary"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col col-xl-4 col-sm-6">
                            <div class="product-box">
                                <div class="product-img pt-4 px-4">
                                    <div class="product-ribbon badge bg-danger"> - 10 %</div>
                                    <div class="product-wishlist"><a href="#"><i class="mdi mdi-heart-outline"></i></a>
                                    </div>
                                    <img src="/minible/vue/v-light/img/img-6.fed9193e.png" alt=""
                                         class="img-fluid mx-auto d-block"></div>
                                <div class="text-center product-content p-4"><h5 class="mb-1"><a
                                    href="/minible/vue/v-light/ecommerce/product-detail/6" class="nav-link">Nike N012
                                    Shoes</a></h5>
                                    <p class="text-muted font-size-13">Gray, Shoes</p>
                                    <h5 class="mt-3 mb-0"><span class="text-muted me-2"><del>$270</del></span> $260</h5>
                                    <ul class="list-inline mb-0 text-muted product-color">
                                        <li class="list-inline-item">Colors :</li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-dark"></i></li>
                                        <li class="list-inline-item"><i class="mdi mdi-circle text-light"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row row mt-4">
                        <div class="col-lg-12">
                            <ul class="pagination pagination-md justify-content-start b-pagination-pills justify-content-center"
                                role="menubar" aria-disabled="false" aria-label="Pagination">
                                <li class="page-item disabled"><span class="page-link" aria-label="Go to first page"
                                                                     aria-controls="my-table" aria-disabled="true"
                                                                     role="menuitem">«</span></li>
                                <li class="page-item disabled"><span class="page-link" aria-label="Go to first page"
                                                                     aria-controls="my-table" aria-disabled="true"
                                                                     role="menuitem">‹</span></li>
                                <li class="page-item active" role="presentation">
                                    <button class="page-link" aria-controls="my-table" aria-label="Go to page 1"
                                            role="menuitemradio" type="button" tabindex="0">1
                                    </button>
                                </li>
                                <li class="page-item disabled"><span class="page-link" aria-label="Go to next page"
                                                                     aria-controls="my-table" aria-disabled="true"
                                                                     role="menuitem">›</span></li>
                                <li class="page-item disabled"><span class="page-link" aria-label="Go to last page"
                                                                     aria-controls="my-table" aria-disabled="true"
                                                                     role="menuitem">»</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div><!----><!----></div>
    </div>
</template>

<script>
export default {
    name: "APL"
}
</script>

<style scoped>

</style>
