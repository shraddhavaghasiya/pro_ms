<template>
    <Layout>
        <PageHeader :title="title" :items="items"/>
        <loader-component :is-visible="isLoading"></loader-component>
        <div class="row">
            <div class="col-lg-12">
                <div id="addproduct-accordion" class="custom-accordion">
                    <form enctype="multipart/form-data" v-on:submit.prevent="saveForm">
                        <div class="card">
                            <a
                                href="javascript: void(0);"
                                class="text-dark"
                                data-toggle="collapse"
                                aria-expanded="true"
                                aria-controls="addproduct-billinginfo-collapse"
                                v-b-toggle.accordion-1
                            >
                                <div class="p-4">
                                    <div class="media align-items-center">
                                        <div class="me-3">
                                            <div class="avatar-xs">
                                                <div
                                                    class="avatar-title rounded-circle bg-soft-primary text-primary"
                                                >
                                                    01
                                                </div>
                                            </div>
                                        </div>
                                        <div class="media-body overflow-hidden">
                                            <h5 class="font-size-16 mb-1">Product Info</h5>
                                            <p class="text-muted text-truncate mb-0">
                                                Fill all information below
                                            </p>
                                        </div>
<!--                                        <i-->
<!--                                            class="mdi mdi-chevron-up accor-down-icon font-size-24"-->
<!--                                        ></i>-->
                                    </div>
                                </div>
                            </a>

<!--                            <b-collapse-->
<!--                                data-parent="#addproduct-accordion"-->
<!--                                id="accordion-1"-->
<!--                                visible-->
<!--                                accordion="my-accordion"-->
<!--                            >-->
<!--                            </b-collapse>-->
                            <div class="p-4 border-top">
                                <div class="form-group row">
                                    <div class="col-lg-8">
                                        <!-- todo: Shopify Title -->
                                        <div class="col-md-12">
                                            <label for="name" class="ml-1 col-form-label">Product Name<span
                                                class="text-danger required">*</span></label>
                                            <input type="text"
                                                   class="form-control"
                                                   id="name"
                                                   v-model="form.name"
                                                   maxlength="190"
                                                   placeholder="Product Name" required="required">
                                        </div>
                                        <div class="mb-3 mt-3 mb-0">
                                            <label for="productdesc">Product Description
                                                <span
                                                    class="text-danger required">*</span></label>
                                            <textarea
                                                rows="4"
                                                class="form-control"
                                                id="productdesc"
                                                v-model="form.description"
                                                maxlength="2000"
                                                placeholder="Description"
                                                required="required"></textarea>
                                        </div>
                                    </div>

                                    <!--Vish Image-->
                                    <div class="col-lg-4 mt-4">
                                        <label for="userProfilePicture" class="text-center w-100 mb-4">Product
                                            Picture</label>
                                        <div class="edit-user-details__avatar m-auto">
                                            <img
                                                :src="form.selected_product_image"
                                                alt="Product Image">
                                        </div>
                                        <label
                                            class="btn btn-primary btn-sm d-table mx-auto mt-4"
                                            :class="dangerClass">
                                            <i class="material-icons"></i>
                                            Browse
                                            <input
                                                ref="upload"
                                                type="file"
                                                name="file-upload"
                                                accept="image/jpeg, image/jpg , image/png , image/gif , image/svg"
                                                id="userProfilePicture"
                                                hidden
                                                v-on:change="productImageChange">
                                        </label>
                                        <div class="text-center">
                                                <span v-if="showProductImageError"
                                                      class="text-danger text-center mt-1 mb-1">{{productImageErrors}}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-4">
                                        <label for="cost-price"
                                               class="ml-1 col-form-label">Price (M.R.P)<span
                                            class="text-danger required">*</span></label>
                                        <input type="number"
                                               class="form-control float_numberPrevClass"
                                               id="cost-price"
                                               v-model="form.price"
                                               maxlength="190"
                                               min="0"
                                               step=".01"
                                               placeholder="Price"
                                               required="required">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="china-price"
                                               class="ml-1 col-form-label">China Price<span
                                            class="text-danger required">*</span></label>
                                        <input type="number"
                                               class="form-control float_numberPrevClass"
                                               id="china-price"
                                               v-model="form.china_price"
                                               maxlength="190"
                                               min="0"
                                               step=".01"
                                               placeholder="China Price">
<!--                                               required="required"-->

                                    </div>

                                    <div class="col-md-4">
                                        <label for="qty"
                                               class="ml-1 col-form-label">Qty<span
                                            class="text-danger required">*</span></label>
                                        <input type="number"
                                               class="form-control numberPrevClass"
                                               id="qty"
                                               v-model="form.qty"
                                               maxlength="190"
                                               min="1"
                                               placeholder="QTY"
                                               required="required">
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-4">
                                        <label for="tag"
                                               class="ml-1 col-form-label">Tag
                                            <span
                                                class="text-danger required">*</span></label>
                                        <select v-model="form.tag"
                                                class="form-control"
                                                id="tag"
                                                required="required">
                                            <option disabled value="">Select Tag</option>
                                            <option value="New">New</option>
                                            <option value="Normal">Normal</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="category"
                                               class="ml-1 col-form-label">Category
                                            <span
                                                class="text-danger required">*</span></label>
                                        <select v-model="form.category"
                                                class="form-control"
                                                id="category"
                                                required="required">
                                            <option disabled value="">Choose a category
                                            </option>
                                            <option v-for="option in categoryOptions"
                                                    v-bind:value="option.id">
                                                {{ option.name }}
                                            </option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="card" style="display: none;">
                            <a
                                href="javascript: void(0);"
                                class="text-dark"
                                data-toggle="collapse"
                                aria-expanded="true"
                                aria-controls="addproduct-img-collapse"
                                v-b-toggle.accordion-2
                            >
                                <div class="p-4">
                                    <div class="media align-items-center">
                                        <div class="me-3">
                                            <div class="avatar-xs">
                                                <div
                                                    class="avatar-title rounded-circle bg-soft-primary text-primary"
                                                >
                                                    02
                                                </div>
                                            </div>
                                        </div>
                                        <div class="media-body overflow-hidden">
                                            <h5 class="font-size-16 mb-1">Product Image</h5>
                                            <p class="text-muted text-truncate mb-0">
                                                Fill all information below
                                            </p>
                                        </div>
<!--                                        <i-->
<!--                                            class="mdi mdi-chevron-up accor-down-icon font-size-24"-->
<!--                                        ></i>-->
                                    </div>
                                </div>
                            </a>

<!--                            <b-collapse-->
<!--                                data-parent="#addproduct-accordion"-->
<!--                                id="accordion-2"-->
<!--                                visible-->
<!--                                accordion="my-accordion"-->
<!--                            ></b-collapse>-->
                            <div class="p-4 border-top">
                                <div class="col-lg-12 mt-4">
                                    <label for="productMultiplePicture"
                                           class="text-center w-100 mb-4">
                                        <!--Product Multiple Picture-->
                                    </label>
                                    <span
                                        v-for="(selected_product_multiple_image , index) in form.selected_product_multiple_images">
                                                        <div class="edit-user-details__avatar_vish mr-2"
                                                             style="display: inline-block;">

                                                                <img :src="selected_product_multiple_image"
                                                                     alt="Product Multiple Image" class="img-thumbnail">

                                                            <!--<label class="edit-user-details__avatar__change_vish">
                                                                <i class="fa fa-plus" aria-hidden="true"></i>
                                                            </label>-->
                                                        </div>
                                                            <span>
                                                                <a class="btn btn-light btn-circle"
                                                                   v-on:click.prevent="deleteSpecificImage(index, selected_product_multiple_image)"><i
                                                                    class="far fa-trash-alt"></i>
                                                                </a>
                                                            </span>
                                                        </span>

                                    <label
                                        class="btn btn-primary btn-sm d-table mx-auto mt-4"
                                        :class="dangerClassPM">
                                        <i class="material-icons"></i>
                                        click to upload

                                        <input
                                            ref="upload"
                                            type="file"
                                            name="multi-file-upload"
                                            multiple=""
                                            accept="image/jpeg, image/jpg , image/png , image/gif"
                                            hidden
                                            id="productMultiplePicture"
                                            v-on:change="productMultipleImageChange">
                                    </label>
                                    <div class="text-center">
                                                                <span v-if="showProductMultiImageError"
                                                                      class="text-danger text-center mt-1 mb-1">{{
                                                                        productMultiImageErrors
                                                                    }}</span>
                                    </div>

                                    <!-- <button
                                        class="btn btn-white d-table mx-auto mt-4 btn-primary btn-sm">
                                        <i
                                            class="material-icons"></i> Upload Image
                                    </button> -->
                                </div>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col text-end ms-1">
                                <button type="submit"
                                        class="btn btn-success ms-1 button-prevent-multiple-submits">
                                    <i class="uil uil-file-alt me-1"></i>Submit
                                </button>
                                <router-link to="/product-list"
                                             class="btn btn-danger">
                                    <i class="uil uil-times me-1"></i>
                                    Cancel
                                </router-link>
                            </div>
                            <!-- end col -->
                        </div>
                    </form>

                </div>
            </div>
        </div>

    </Layout>
</template>

<script>
import PageHeader from "../../../common/page-header";
import Layout from "../../layouts/layout";
import LoaderComponent from "../../../common/LoaderComponent";

/**
 * Add-product component
 */
export default {
    name: "ProductAdd",
    page: {
        title: "Add Product",
        meta: [
            {
                name: "description",
            },
        ],
    },
    components: {
        LoaderComponent,
        Layout,
        PageHeader,
    },
    data() {
        return {
            title: "Products Add",
            items: [
                {
                    text: "Product",
                },
                {
                    text: "Add",
                    active: true,
                },
            ],
            value1: null,
            form: {
                //Todo: Product Info
                name: '',
                description: '',
                price: '',
                china_price: '',
                qty: '',
                tag: '',
                category: '',
                product_image: '',
                selected_product_image: '/storage/product_images/product_thumbnail.png',

                product_multi_image: [],
                selected_product_multiple_images: [],
            },
            categoryOptions: [],
            isLoading: false,
            errors: [],
            showProductImageError: '',
            productImageErrors: '',

            showProductMultiImageError: '',
            productMultiImageErrors: '',
            dangerClass: '',
            dangerClassPM: '',
            limit: 10,
            search: '',
        };
    },
    methods: {
        checkForm() {
            //&& this.form.browse_node && this.form.hsn_code && this.form.country this.form.ebay_title !== null && this.form.amazon_title !== null &&
            if (this.form.name !== null && this.form.description !== null
                && this.form.price !== null
                && this.form.china_price !== null
                && this.form.qty !== null
                && this.form.tag !== null
            ) {
                return true;
            } else {
                this.showToast('please fill all input field', 'error')
                return false;
            }
        },
        getCategory() {
            var self = this;
            self.isLoading = true;
            axios.get(self.bUrl + '/product/get-category').then((response) => {

                self.categoryOptions = [];

                // Todo: Try 3rd using data map and custome spread object
                response.data.category.map(function (value, key) {
                    self.categoryOptions.push({
                        ...{
                            'id': value.id,
                            'name': value.name
                        }
                    });
                });
                self.isLoading = false;

            }).catch((e) => {
                console.log(e);
            })
        },
        deleteSpecificImage(index, image) {

            // console.log(index);
            // console.log(image);

            let conformed = confirm('Are You Sure remove Image?');
            if (conformed) {
                // console.log({'i': i, 'pid': pid, 'view': viewValue});
                this.form.product_multi_image.splice(index, 1);
                this.form.selected_product_multiple_images.splice(index, 1);
                this.showToast('Image removed successfully', 'success');
            }
        },
        saveForm() {
            if (this.checkForm()) {


                const config = {
                    headers: {'content-type': 'multipart/form-data'}
                }

                let formData = new FormData();
                formData.append('name', this.form.name);
                formData.append('description', this.form.description);
                formData.append('price', this.form.price);
                formData.append('china_price', this.form.china_price);
                formData.append('qty', this.form.qty);
                formData.append('tag', this.form.tag);
                formData.append('category', this.form.category);


                formData.append('product_image', this.form.product_image);
                // formData.append('product_multi_image', this.form.product_multi_image);

                $.each(this.form.product_multi_image, function (key, image) {
                    formData.append(`product_multi_image[${key}]`, image);
                })

                formData.append('selected_product_image', this.form.selected_product_image);
                formData.append('selected_product_multiple_images', this.form.selected_product_multiple_images);

                let self = this;
                self.isLoading = true;
                axios.post(self.bUrl + '/product/admin-product-register', formData, config).then((response) => {
                    console.log('saved');
                    console.log(response);
                    console.log(JSON.stringify(response.data.success));
                    console.log(JSON.stringify(response.data.message));

                    if (response.data.success === false) {
                        self.showToast(response.data.message, 'error');
                        self.isLoading = false;
                    } else if (response.data.success === true) {
                        self.showToast(response.data.message, 'success');
                        self.isLoading = false;
                        self.$router.push('/product-list');
                    }
                }).catch((error) => {
                    self.errors.push(error);
                    // self.showToast(error, 'error');
                    if (typeof error.response.data.errors.china_price != 'undefined') {
                        if (typeof error.response.data.errors.china_price[0] != 'undefined') {
                            self.showToast(error.response.data.errors.china_price[0], 'error');
                        }
                    }
                    if (typeof error.response.data.errors.product_image != 'undefined') {
                        if (typeof error.response.data.errors.product_image[0] != 'undefined') {
                            self.showToast(error.response.data.errors.product_image[0], 'error');
                        }
                    }
                    self.isLoading = false;
                })
            }
        },

        productImageChange(event) {
            this.isLoading = true;

            const file = event.target.files[0];
            if (file) {
                var fileType = file["type"]; // file.type
                var validImageTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/svg+xml"];
                if ($.inArray(fileType, validImageTypes) < 0) {

                    // console.log(fileType);
                    this.showProductImageError = true;
                    this.productImageErrors = 'Invalid image format';
                    this.dangerClass = 'btn-danger';
                    this.isLoading = false;

                    this.form.selected_product_image = 'storage/product_thumbnail/product_thumbnail.jpg';
                    this.form.product_image = '';
                    return false;
                } else {
                    if (file.size / 1024 / 1024 <= 2) {
                        this.form.selected_product_image = URL.createObjectURL(file); // use preview
                        this.form.product_image = event.target.files[0]; // DB STORE
                        console.log(this.form.product_image);
                        this.showProductImageError = false;
                        this.productImageErrors = '';
                        this.dangerClass = '';
                        this.isLoading = false;
                    } else {
                        this.showProductImageError = true;
                        this.productImageErrors = 'The product image may not be greater than 2048 kilobytes.';
                        this.dangerClass = 'btn-danger';
                        this.form.selected_product_image = 'storage/product_thumbnail/product_thumbnail.jpg';
                        this.form.product_image = '';
                        this.isLoading = false;
                        return false;
                    }
                }
            } else {
                this.showProductImageError = true;
                this.productImageErrors = 'Please Select Product Image';
                this.dangerClass = 'btn-danger';
                this.form.selected_product_image = 'storage/product_thumbnail/product_thumbnail.jpg';
                this.form.product_image = '';
                this.isLoading = false;
                return false;
            }
        },

        productMultipleImageChange(event) {
            this.isLoading = true;
            console.log(event.target.files);

            if (event.target.files) {
                var filesAmount = event.target.files.length;
                for (var i = 0; i < filesAmount; i++) {
                    const file = event.target.files[i];
                    // this.form.product_multi_image = [];
                    if (file) {
                        var fileType = file["type"]; // file.type
                        var validImageTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif", "image/svg+xml"];
                        if ($.inArray(fileType, validImageTypes) < 0) {

                            // console.log(fileType);
                            this.showProductMultiImageError = true;
                            this.productMultiImageErrors = 'Invalid image format';
                            this.dangerClassPM = 'btn-danger';
                            this.isLoading = false;
                            console.log(this.form.product_multi_image);
                            return false;
                        } else {
                            if (file.size / 1024 / 1024 <= 2) {
                                this.form.selected_product_multiple_images.push(URL.createObjectURL(file)); // use preview
                                this.form.product_multi_image.push(event.target.files[i]); // DB STORE
                                console.log(this.form.product_multi_image);
                                this.showProductMultiImageError = false;
                                // this.productMultiImageErrors = '';
                                this.dangerClassPM = '';
                                this.isLoading = false;
                            } else {
                                this.showProductMultiImageError = true;
                                this.productMultiImageErrors = 'The product image may not be greater than 2048 kilobytes.';
                                this.dangerClassPM = 'btn-danger';
                                console.log(this.form.product_multi_image);
                                this.isLoading = false;
                                return false;
                            }
                        }
                    } else {
                        this.showProductMultiImageError = true;
                        this.productMultiImageErrors = 'Please Select Product Image';
                        this.dangerClassPM = 'btn-danger';
                        this.form.product_multi_image = '';
                        this.isLoading = false;
                        return false;
                    }
                }
            } else {
                this.showProductMultiImageError = true;
                this.productMultiImageErrors = 'Please Select Product Image';
                this.dangerClassPM = 'btn-danger';
                this.form.product_multi_image = '';
                this.isLoading = false;
                return false;
            }
            this.isLoading = false;
            console.log(this.form.product_multi_image, 'final');
        },
        async onOpen() {
            if (this.hasNextPage) {
                await this.$nextTick();
                this.observer.observe(this.$refs.load)
            }
        },
        onClose() {
            this.observer.disconnect();
        },
        async infiniteScroll([{isIntersecting, target}]) {
            if (isIntersecting) {
                const ul = target.offsetParent;
                const scrollTop = target.offsetParent.scrollTop;
                this.limit += 10;
                await this.$nextTick();
                ul.scrollTop = scrollTop;
            }
        }
    },
    mounted() {
        this.observer = new IntersectionObserver(this.infiniteScroll);
    },
    created() {
        this.checkIfLogged();
        this.getCategory();
    },
    // middleware: "authentication",
};
</script>

<style scoped>
.edit-user-details__avatar {
    border-radius: 10%;
    overflow: hidden;
    position: relative;
    max-width: 7.5rem;
    /*-webkit-box-shadow: 0 2px 0 rgb(90 97 105 / 11%), 0 4px 8px rgb(90 97 105 / 12%), 0 10px 10px rgb(90 97 105 / 6%), 0 7px 70px rgb(90 97 105 / 10%);*/
    box-shadow: 0 2px 0 rgb(90 97 105 / 11%), 0 4px 8px rgb(90 97 105 / 12%), 0 10px 10px rgb(90 97 105 / 6%), 0 7px 70px rgb(90 97 105 / 10%);
}

.edit-user-details__avatar img {
    width: 100%;
}

img, svg {
    vertical-align: middle;
}

img {
    border-style: none;
}

.edit-user-details__avatar__change i {
    color: #9ea8b9;
    line-height: 7.5rem;
}

i.material-icons {
    top: 2px;
}

i.material-icons {
    font-size: inherit;
    position: relative;
}

.edit-user-details__avatar_vish {
    border-radius: 10%;
    overflow: hidden;
    position: relative;
    max-width: 7.5rem;
    height: 120px !important;
    -webkit-box-shadow: 0 2px 0 rgb(90 97 105 / 11%), 0 4px 8px rgb(90 97 105 / 12%), 0 10px 10px rgb(90 97 105 / 6%), 0 7px 70px rgb(90 97 105 / 10%);
    box-shadow: 0 2px 0 rgb(90 97 105 / 11%), 0 4px 8px rgb(90 97 105 / 12%), 0 10px 10px rgb(90 97 105 / 6%), 0 7px 70px rgb(90 97 105 / 10%);
}

</style>
