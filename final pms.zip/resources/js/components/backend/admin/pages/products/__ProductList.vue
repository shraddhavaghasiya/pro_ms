<template>
    <Layout>
        <PageHeader :title="title" :items="items"/>
        <loader-component :is-visible="isLoading"></loader-component>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <router-link to="/product-add"
                                 type="button"
                                 class="btn btn-success waves-effect waves-light">
                        <i class="mdi mdi-plus me-2"></i>
                        Add New Product
                    </router-link>
                    <!--<vendor-add-modal
                        v-on:callback="setUserEmit($event)"
                        :key="componentKey"
                        :clickToClose="false"
                    ></vendor-add-modal>-->
                </div>
            </div>
            <div class="col-12" v-if="productNotFound === ''">
                <div class="row mt-4">
                    <div class="col-sm-12 col-md-6">
                        <div id="tickets-table_length" class="dataTables_length">
                            <label class="d-inline-flex align-items-center fw-normal">
                                Show&nbsp;
                                <b-form-select v-model="perPage" size="sm" :options="pageOptions">
                                </b-form-select>&nbsp;entries
                            </label>
                        </div>
                    </div>
                    <!-- Search -->
                    <div class="col-sm-12 col-md-6">
                        <div id="tickets-table_filter" class="dataTables_filter text-md-end">
                            <label class="d-inline-flex align-items-center fw-normal">
                                Search:
                                <b-form-input v-model="filter" type="search"
                                              class="form-control rounded form-control-sm ms-2"></b-form-input>
                            </label>
                        </div>
                    </div>
                    <!-- End search -->
                </div>
                <!-- Table -->
                <div class="row">
                    <div class="col col-xl-4 col-sm-6" v-for="(product, index) in products">
                        <div class="product-box">
                            <div class="product-img pt-4 px-4">
<!--                                <div class="product-ribbon badge bg-danger"> - 20 %</div>-->
<!--                                <div class="product-wishlist"><a href="#"><i class="mdi mdi-heart-outline"></i></a>-->
<!--                                </div>-->
                                <img v-if="product.image" :src="'./storage/'+product.image" alt=""
                                     class="img-fluid mx-auto d-block"></div>
                            <div class="text-center product-content p-4"><h5 class="mb-1">
                                <router-link
                                    :to="{ name: 'product_edit', params: { Pid: product.id}}"
                                    class="nav-link">{{ product.name }}
                                </router-link>
<!--                                <a href="/minible/vue/v-light/ecommerce/product-detail/1" class="nav-link">{{ product.name }}</a>-->
                            </h5>
                                <p class="text-muted font-size-13">{{ product.qty }}</p>
                                <h5 class="mt-3 mb-0"><span class="text-muted me-2"></span> $ {{product.price}}</h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive mb-0">
                    <b-table table-class="table table-centered datatable table-card-list"
                             thead-tr-class="bg-transparent"

                             id="my-table"
                             :busy.sync="isBusy"
                             :items="getProductInfoList"
                             :fields="fields"

                             :key="componentKey"
                             :current-page="currentPage"
                             :per-page="perPage"
                             striped
                             fixed
                             responsive="sm"
                             :filter="filter"
                             :sort-by.sync="sortBy"
                             :sort-desc.sync="sortDesc"
                             :filter-included-fields="filterOn">
                        <!--                        @filtered="onFiltered"-->

                        <template v-slot:cell(id)="data">
                            <div class="ml-2"> #{{ data.index + 1 }}</div>
                        </template>

                        <template v-slot:cell(name)="data">
                            <img v-if="data.item.image" :src="'./storage/'+data.item.image" alt
                                 class="avatar-xs rounded-circle me-2"/>
                            <div v-else class="avatar-xs d-inline-block me-2">
                                <span class="avatar-title rounded-circle bg-light text-body">{{data.item.name.charAt(0)}}</span>
                            </div>
                            <router-link
                                :to="{ name: 'product_edit', params: { Pid: data.item.id}}"
                                class="text-body">{{ data.item.name }}
                            </router-link>
                        </template>

                        <template v-slot:cell(status)="data">
                            <div class="badge bg-pill bg-soft-success font-size-12"
                                 :class="{'bg-soft-danger': data.item.status == '0'}">
                                                <span v-if="data.item.status === 0">
                                                    <a v-on:click="toggleProductStatus(data.index , data.item.id , 1)"
                                                       title="Click to change status active" style="cursor: pointer;">
                                                            <span class="rounded-pill">
                                                            InActive
                                                            </span>
                                                        </a>
                                                </span>
                                <span v-else>
                                                        <a v-on:click="toggleProductStatus(data.index , data.item.id , 0)"
                                                           title="Click to change status inactive"
                                                           style="cursor: pointer; ">
                                                            <span class="rounded-pill">
                                                                Active
                                                            </span>
                                                        </a>
                                                </span>
                            </div>
                        </template>
                        <template v-slot:cell(action)="data">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <router-link
                                        :to="{ name: 'product_view', params: { Pid: data.item.id}}"
                                        class="btn px-2 text-primary"
                                        v-b-tooltip.hover
                                        title="View">
                                        <i class="uil uil-store font-size-18"></i>
                                    </router-link>
                                </li>
                                <li class="list-inline-item">
                                    <router-link
                                        :to="{ name: 'product_edit', params: { Pid: data.item.id}}"
                                        class="btn px-2 text-primary"
                                        v-b-tooltip.hover
                                        title="Edit">
                                        <i class="uil uil-pen font-size-18"></i>
                                    </router-link>
                                </li>
                                <li class="list-inline-item">
                                    <a class="px-2 text-danger" v-b-tooltip.hover
                                       title="Delete"
                                       @click="deleteProduct(data.index, data.item.id)">
                                        <i class="uil uil-trash-alt font-size-18"></i>
                                    </a>
                                </li>
                            </ul>
                        </template>
                    </b-table>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="dataTables_paginate paging_simple_numbers float-end">
                            <ul class="pagination pagination-rounded">
                                <b-pagination
                                    v-model="currentPage"
                                    :total-rows="totalRows"
                                    :per-page="perPage"></b-pagination>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else>
                <div class="card">
                    <h3 class="text-center text-danger my-5">
                        Product Not Available
                    </h3>
                </div>
            </div>
        </div>
    </Layout>
</template>

<script>
import Layout from "../../layouts/layout";
import PageHeader from "../../../common/page-header";
import appConfig from "../../../../../app.config.json";
import LoaderComponent from "../../../common/LoaderComponent";

/**
 * Customer component
 */
export default {
    name: 'ProductsList',
    components: {LoaderComponent, Layout, PageHeader},
    page: {
        title: "Products",
        meta: [
            {
                name: "description",
                content: appConfig.description,
            },
        ],
    },
    data() {
        return {
            // -----
            componentKey: 0,
            // currentProduct: [],

            title: "Products",
            items: [{
                text: "Products",
            },
                {
                    text: "Products",
                    active: true,
                },
            ],

            isBusy: false,
            isLoading: false,

            productNotFound: '',

            products: [],

            totalRows: 1,
            currentPage: 1,
            perPage: 25,
            pageOptions: [2, 5, 10, 25, 50, 100],
            filter: null,

            filterOn: [],
            sortBy: "price",
            sortDesc: true,
            fields: [
                {
                    key: "id",
                    label: "Id",
                    class: "col-md-1",
                    sortable: true,
                },
                {
                    key: "name",
                    label: "Product Details",
                    sortable: true,
                    class: "col-md-3 th_title_class",
                },
                {
                    key: "price",
                    sortable: true,
                    class: "col-md-1",
                },
                {
                    key: "qty",
                    label: "Stock",
                    sortable: true,
                    class: "col-md-1",
                },
                {
                    key: "status",
                    label: "Status",
                    class: "col-md-1",
                    sortable: true
                },
                {
                    key: "action",
                    class: "col-md-1",
                }
                // "action",
            ],
        };
    },

    methods: {
        deleteProduct(index, id) {
            this.$swal({
                title: 'Are you sure?',
                text: "Are you sure you want to delete this item?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#89b6ea',
                cancelButtonColor: '#f37a7a',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    var self = this;
                    self.isLoading = true;
                    axios.post(self.bUrl + '/product/product-delete-update', {
                        id: id
                    }).then(function (response) {
                        if (!response.data.error) {
                            console.log(response.data);

                            self.products.splice(index, 1);
                            self.totalRows -= 1;
                            self.$swal({
                                text: response.data.success,
                                icon: "success",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                },
                                timer: 1500
                            })
                            self.isLoading = false;
                        } else {
                            console.log(response.data.error);
                            self.$swal({
                                text: response.data.error,
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            })
                            self.isLoading = false;
                        }
                        self.tableComponentKey += 1;
                        self.componentKey += 1;
                        self.isLoading = false;
                    }).catch(function (error) {
                        console.log(error);
                        self.$swal({
                            text: error,
                            icon: "error",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        })
                    });
                } else if (result.dismiss === this.$swal.DismissReason.cancel) {
                    this.$swal.fire(
                        'Cancelled',
                        'Your imaginary data is safe :)',
                        'error'
                    )
                }
            });
        },
        toggleProductStatus(i, pid, viewValue) {
            // console.log({'i': i, 'pid': pid, 'view': viewValue});
            var self = this;
            self.isLoading = true;
            axios.post(self.bUrl + '/product/product-status-update', {
                productId: pid,
                status: viewValue
            }).then(function (response) {
                console.log(JSON.stringify(response.data));
                if (!response.data.error) {
                    console.log(response.data);

                    self.products[i].status = response.data.status;
                    self.isLoading = false;
                    self.showToast(response.data.success, 'success');
                } else {
                    console.log(response.data.error);
                    self.showToast(response.data.error, 'error');
                    self.isLoading = false;
                }
            }).catch(function (error) {
                console.log(error);
                self.showToast(error, 'error');
            });
        },

        v1getProductInfoList(ctx) {
            // console.log(ctx);
            if (ctx.filter === null || ctx.filter === '') {
                // console.log(ctx.filter);
                this.isBusy = true
                this.isLoading = true
                let promise = axios.get('/product/admin-product-list/' + ctx.sortBy + '/' + ctx.sortDesc + '/' + ctx.perPage + '?page=' + ctx.currentPage)

                return promise.then((res) => {

                    // console.log(res);
                    // console.log('done');
                    var products = [];
                    products = res.data.data;

                    if (res.data.data.length > 0) {
                        this.products = res.data.data;
                    } else {
                        // console.log(res.data.data);
                        this.productNotFound = 'Product Not Found';
                    }

                    this.currentPage = res.data.current_page;
                    this.totalRows = res.data.total;

                    // console.log(this.totalRows);
                    this.isBusy = false
                    this.isLoading = false;
                    return products;
                    // Here we could override the busy state, setting isBusy to false
                }).catch(error => {
                    // Here we could override the busy state, setting isBusy to false
                    this.isBusy = false
                    this.isLoading = false;
                    // Returning an empty array, allows table to correctly handle
                    // internal busy state in case of error
                    return []
                });
            } else {
                console.log(ctx.filter);
                this.isBusy = true
                this.isLoading = true
                //http://crm.test/admin/product/admin-product-list/10?page=1
                //http://crm.test/get/product_search/10/hp?page=1
                let promise = axios.get('/get/product_search/' + this.perPage + '/' + ctx.filter.toLowerCase() + '?page=' + ctx.currentPage)

                return promise.then((res) => {

                    // console.log(res);
                    // console.log('done');
                    var products = res.data.data;

                    if (res.data.data.length > 0) {
                        this.products = res.data.data;
                    }
                    this.currentPage = res.data.current_page;
                    this.totalRows = res.data.total;

                    // console.log(this.totalRows);
                    this.isBusy = false
                    this.isLoading = false;
                    return products;
                    // Here we could override the busy state, setting isBusy to false
                }).catch(error => {
                    // Here we could override the busy state, setting isBusy to false
                    this.isBusy = false
                    this.isLoading = false;
                    // Returning an empty array, allows table to correctly handle
                    // internal busy state in case of error
                    return []
                });
            }
        },
        getProductInfoList(ctx) {
            console.log('ctx');
            if (ctx.filter === null || ctx.filter === '') {
                var self = this;
                self.isBusy = true;
                self.isLoading = true;

                let promise = axios.get('/product/admin-product-list/' + ctx.perPage + '?page=' + ctx.currentPage)
                return promise.then((responses) => {

                    // if (responses.success === true) {
                    console.log(responses);
                    console.log(responses.data.success);


                    if (responses.data.success === true) {
                        var products = responses.data.productLists.data;
                        responses.data.productLists.data.map((value, key) => {
                            self.products.push(value)
                        })

                        self.currentPage = responses.data.productLists.current_page;
                        self.totalRows = responses.data.productLists.total;

                        // console.log(self.totalRows);
                        self.isBusy = false
                        self.isLoading = false;
                        return products;

                    } else {
                        // alert('product not Found');
                        console.log(responses.data.message);
                        self.productNotFound = responses.data.message;
                    }
                    // } else {
                    //     self.isBusy = false
                    //     self.isLoading = false;
                    //     self.productNotFound = responses.data.message;
                    // }
                    self.isBusy = false
                    self.isLoading = false;
                }).catch((error) => {
                    console.log(error);
                })
            } else {
                // $search_product
                this.isBusy = true
                this.isLoading = true

                //http://crm.test/admin/admin-employee-search/10/vis?page=1
                let filterval = ctx.filter.toLowerCase();
                let promise = axios.get('/product/admin-product-search/' + this.perPage + '/' + filterval + '?page=' + ctx.currentPage)

                return promise.then((res) => {

                    console.log(res);
                    console.log('done');
                    var products = res.data.data;

                    if (res.data.data.length > 0) {
                        this.products = res.data.data;
                    }else {
                        // alert('Product not Found');
                        this.productNotFound = 'Product not Found';
                    }

                    this.currentPage = res.data.current_page;
                    this.totalRows = res.data.total;

                    console.log(this.totalRows);
                    this.isBusy = false
                    this.isLoading = false;
                    return products;
                    // Here we could override the busy state, setting isBusy to false
                }).catch(error => {
                    // Here we could override the busy state, setting isBusy to false
                    this.isBusy = false
                    this.isLoading = false;
                    // Returning an empty array, allows table to correctly handle
                    // internal busy state in case of error
                    return []
                });
            }
        },
    },
    created() {
        this.getProductInfoList(ctx);
        this.checkIfLogged();
    },
    middleware: "authentication",
};
</script>

<style scoped>
.ellipsis {
    text-overflow: ellipsis;
    /* Required for text-overflow to do anything */
    white-space: nowrap;
    overflow: hidden;
}
.mx-auto {
    margin-right: auto!important;
    margin-left: auto!important;
}
.d-block {
    display: block!important;
}
img-fluid, .img-thumbnail {
    max-width: 100%;
    height: auto;
}
img, svg {
    vertical-align: middle;
}
</style>
