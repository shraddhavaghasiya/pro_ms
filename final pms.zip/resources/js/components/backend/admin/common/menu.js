export const menuItems = [
    {
        id: 1,
        label: "menuitems.menu.text",
        isTitle: true
    },
    {
        id: 2,
        label: "menuitems.dashboard.text",
        icon: "uil-home-alt",
        link: "/dashboard",
    },
    {
        id: 3,
        label: "menuitems.contacts.list.profile",
        icon: "uil-home-alt",
        link: "/admin-user-profile",
    },
    //Dashboard list
    {
        id: 4,
        label: "menuitems.apps.text",
        isTitle: true
    },
    {
        id: 5,
        label: "menuitems.users.text",
        icon: "uil-users-alt",
        subItems: [
            {
                id: 5.1,
                label: "menuitems.users.list.user_list",
                link: "/user-list",
                parentId: 5,
            },
        ]
    },
    {
        id: 6,
        label: "menuitems.products.text",
        icon: "uil-home-alt",
        subItems: [
            {
                id: 6.1,
                label: "menuitems.products.list.product_list",
                link: "/product-list",
                parentId: 6,
            },
            {
                id: 6.2,
                label: "menuitems.products.list.product_add",
                link: "/product-add",
                parentId: 6,
            },
        ]
    },

];

