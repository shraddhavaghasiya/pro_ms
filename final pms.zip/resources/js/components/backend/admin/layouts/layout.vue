<script>
// import {
//     layoutComputed
// } from "@/state/helpers";
import Vertical from "./vertical";
/**
 * Main Layout
 */
export default {
    name:'Layout',
    components: {
        Vertical,
    },
    mounted() {
        document.body.classList.remove('authentication-bg')
    },
};
</script>

<template>
<div>
    <Vertical layout="vertical">
        <slot />
    </Vertical>
</div>
</template>
