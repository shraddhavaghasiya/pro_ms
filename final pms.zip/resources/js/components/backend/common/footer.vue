<script>
export default {
    name: 'footer'
}
</script>

<template>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">{{ new Date().getFullYear() }} © Surya Gold.</div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        Crafted with
                        <i class="mdi mdi-heart text-danger"></i> by
                        <a href="https://themesbrand.com/" target="_blank" class="text-reset">Surya Gold</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</template>
