require('./bootstrap');

import Vue from 'vue'
import App from "./components/App";

import VueRouter from 'vue-router'
import Routes from './routes'

Vue.use(VueRouter)

import vSelect from 'vue-select'

Vue.component('v-select', vSelect)
import 'vue-select/dist/vue-select.css';

import 'vue-search-select/dist/VueSearchSelect.css';

import i18n from "./i18n";
import BootstrapVue from 'bootstrap-vue'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.use(BootstrapVue);
require('../../public/assets/scss/app.scss');

import moment from "moment";

Vue.prototype.moment = moment;

import VueSlideBar from 'vue-slide-bar'

Vue.component('VueSlideBar', VueSlideBar)
import VueSweetalert2 from "vue-sweetalert2";
import 'sweetalert2/dist/sweetalert2.min.css';

Vue.use(VueSweetalert2);

import VueToast from 'vue-toast-notification';
import VueCookie from 'vue-cookie';
import 'vue-toast-notification/dist/theme-sugar.css';

Vue.use(VueToast)
Vue.use(VueCookie);

import VueSession from 'vue-session'
Vue.use(VueSession)

import Vuelidate from 'vuelidate'

Vue.use(Vuelidate)

import VueApexCharts from 'vue-apexcharts'
Vue.component('apexchart', VueApexCharts)

const routeConst = new VueRouter({
    base: "/",
    routes: Routes,
    mode: 'history',
    // base: '/'
})


export const bus = new Vue();

Vue.mixin({
    data() {
        return {
            // bUrl: '/instafeed', //live website use in axios
            bUrl: '',
            loginUserId: '',
            loginUserRoleId: '',
            loginUserName: '',
            loginUserAvatar: '',
            getDBOption: 0,
            // userId: '',
        }
    },
    mounted() {
        this.getAuthLoginInfo();
        this.numberInputPreventKey();
        this.checkIfLogged();
    },
    methods: {
        numberInputPreventKey() {
            //Todo: [ (backspace ,null,  0 to 9) only enable ]
            let _numberPrevClass = $('.numberPrevClass');
            _numberPrevClass.on('keypress', function (evt) {
                if (evt.which !== 8 && evt.which !== 0 && evt.which < 48 || evt.which > 57) {
                    evt.preventDefault();
                }
            });
            // alert('e prevent');
            // if (evt.which !== 8 && evt.which !== 0 && evt.which < 48 || evt.which > 57) {
            //     if(evt.which !== 46){
            //         evt.preventDefault();
            //     }
            // }


            //Todo: Float value [ (.) only enable ] -- [ (backspace ,null,  0 to 9) only enable ]
            let _float_numberPrevClass = $('.float_numberPrevClass');
            _float_numberPrevClass.on('keypress', function (evt) {
                if (evt.which !== 46 && evt.which !== 8 && evt.which !== 0 && evt.which < 48 || evt.which > 57) {
                    evt.preventDefault();
                }
            });
        },

        float_numberInputPreventKey() {
        },

        getbeforedate(date){
            return moment(date).add(-1, 'months').format('YYYY,M,D');
        },

        formatPrice(value) {
            // let val = (value/1).toFixed(2).replace('', ',')
            let val = (value / 1).toFixed(2)
            return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        },
        //Todo: Toast notification
        showToast(message, type, duration = 5000, position = 'top') {
            // console.log('mounted app.js')
            // console.log('toast');
            Vue.$toast.open({
                message: message,
                type: type,
                duration: duration,
                position: position,
                dismissible: true,
            })
        },
        getAuthLoginInfo() {

            // this.$session.start()
            // let sess = this.$session.exists()
            // let sess1 = this.$session.getAll()
            // console.log(this.$session.has('userLogin'));
            // console.log(sess);
            // console.log(sess1, 'get');

            // var ul_info = this.$cookie.get('UL');
            // if (ul_info) {
            //     this.loginUserId = atob(ul_info);
            // }


            var ul_info = this.$cookie.get('UL');
            if (ul_info) {
                let userId = ul_info.split('-')[0]; //17841445784476623 //IGQVJXQ0xNLTRlMExIWTByenFmeXpKQXVMdFhqUnZATVnVPT0ZAiS19mQUhBcXIxdzh6Y0t4UlJ1S1A3Q2tObGJqN2daSFA1emxhVDNsVWpXZAlJLTlBUN0t6alhTLUs0cUUtTmhoZAEpnUnBoWDI2a3ZALTUxGeUJWM3M4ZAmtF
                let userRoleId = ul_info.split('-')[1]; //17841445784476623 //IGQVJXQ0xNLTRlMExIWTByenFmeXpKQXVMdFhqUnZATVnVPT0ZAiS19mQUhBcXIxdzh6Y0t4UlJ1S1A3Q2tObGJqN2daSFA1emxhVDNsVWpXZAlJLTlBUN0t6alhTLUs0cUUtTmhoZAEpnUnBoWDI2a3ZALTUxGeUJWM3M4ZAmtF
                let userAvatar = ul_info.split('-')[2]; //17841445784476623 //IGQVJXQ0xNLTRlMExIWTByenFmeXpKQXVMdFhqUnZATVnVPT0ZAiS19mQUhBcXIxdzh6Y0t4UlJ1S1A3Q2tObGJqN2daSFA1emxhVDNsVWpXZAlJLTlBUN0t6alhTLUs0cUUtTmhoZAEpnUnBoWDI2a3ZALTUxGeUJWM3M4ZAmtF
                this.loginUserId = atob(userId);
                this.loginUserRoleId = atob(userRoleId);
                this.loginUserAvatar = atob(userAvatar);
                // console.log(this.loginUserAvatar);

                // console.log('loginUserId' + this.loginUserId);
                // console.log('loginUserRoleId' + this.loginUserRoleId);
            }

            var ul_loginUserName = this.$cookie.get('UL_Name');
            if (ul_loginUserName) {
                this.loginUserName = ul_loginUserName.replaceAll("+", " ");
            }
            // console.log(this.loginUserName);
        },

        checkIfLogged() {
            var self = this;
            axios.get(self.bUrl + '/sessionStatus').then(response => {
                if (response.data.success === true) {
                    // console.log(response.data.message);
                    this.getAuthLoginInfo();
                } else if (response.data.success === false) {
                    // console.log(response.data.message);
                    this.getAuthLoginInfo();
                }
            }).catch(error => {
                console.log(error.response.data);
            })
        }
    }
})


const app = new Vue({
    el: '#app',
    components: {
        'srd': App
    },
    router: routeConst,
    i18n,
});
